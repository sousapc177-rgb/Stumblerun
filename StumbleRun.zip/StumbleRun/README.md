# Stumble Run
Jogo estilo Stumble Guys (Kotlin + OpenGL ES 2.0). Personagem: skin1_model.glb (Mr Stumble) em app/src/main/assets.
Enviou pro GitHub -> aba Actions -> "Build APK" -> baixar "StumbleRun-APK".
