package com.stumble.run

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader

/** Desenhos usados no menu e na corrida. */
object Icons {
    fun crown(c: Canvas, p: Paint, path: Path, cx: Float, cy: Float, s: Float) {
        p.shader = null; p.style = Paint.Style.FILL
        val l = cx - s; val r = cx + s; val b = cy + s * 0.65f
        val top = cy - s * 0.8f; val mid = cy - s * 0.45f
        path.reset()
        path.moveTo(l, b); path.lineTo(l - s * 0.05f, mid); path.lineTo(cx - s * 0.5f, cy + s * 0.05f)
        path.lineTo(cx, top); path.lineTo(cx + s * 0.5f, cy + s * 0.05f); path.lineTo(r + s * 0.05f, mid)
        path.lineTo(r, b); path.close()
        p.color = 0xFFFFC62D.toInt(); c.drawPath(path, p)
        p.color = 0xFFE08A00.toInt(); c.drawRect(l, b - s * 0.32f, r, b, p)
        p.color = 0xFFFFF3B0.toInt()
        c.drawCircle(cx, top, s * 0.13f, p)
        c.drawCircle(l - s * 0.05f, mid, s * 0.12f, p)
        c.drawCircle(r + s * 0.05f, mid, s * 0.12f, p)
    }

    fun gem(c: Canvas, p: Paint, path: Path, cx: Float, cy: Float, r: Float) {
        p.shader = null; p.style = Paint.Style.FILL
        path.reset()
        path.moveTo(cx, cy - r); path.lineTo(cx + r * 0.9f, cy - r * 0.35f); path.lineTo(cx + r * 0.9f, cy + r * 0.35f)
        path.lineTo(cx, cy + r); path.lineTo(cx - r * 0.9f, cy + r * 0.35f); path.lineTo(cx - r * 0.9f, cy - r * 0.35f)
        path.close()
        p.color = 0xFF2FD14A.toInt(); c.drawPath(path, p)
        p.color = 0xFF8CF29A.toInt()
        path.reset(); path.moveTo(cx, cy - r); path.lineTo(cx + r * 0.9f, cy - r * 0.35f)
        path.lineTo(cx, cy); path.lineTo(cx - r * 0.9f, cy - r * 0.35f); path.close()
        c.drawPath(path, p)
    }

    /** botão direcional redondo com setinhas (kx, ky = posição da bolinha) */
    fun joystick(c: Canvas, p: Paint, path: Path, cx: Float, cy: Float, r: Float, kx: Float, ky: Float) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = Color.argb(110, 10, 10, 10)
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.045f; p.color = Color.argb(220, 230, 230, 230)
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.FILL; p.color = Color.argb(230, 200, 200, 200)
        val d = r * 0.8f; val a = r * 0.09f
        path.reset(); path.moveTo(cx, cy - d - a); path.lineTo(cx - a, cy - d + a); path.lineTo(cx + a, cy - d + a); path.close(); c.drawPath(path, p)
        path.reset(); path.moveTo(cx, cy + d + a); path.lineTo(cx - a, cy + d - a); path.lineTo(cx + a, cy + d - a); path.close(); c.drawPath(path, p)
        path.reset(); path.moveTo(cx - d - a, cy); path.lineTo(cx - d + a, cy - a); path.lineTo(cx - d + a, cy + a); path.close(); c.drawPath(path, p)
        path.reset(); path.moveTo(cx + d + a, cy); path.lineTo(cx + d - a, cy - a); path.lineTo(cx + d - a, cy + a); path.close(); c.drawPath(path, p)
        p.shader = RadialGradient(kx - r * 0.1f, ky - r * 0.1f, r * 0.45f, 0xFFFFFFFF.toInt(), 0xFFB5B5B5.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(kx, ky, r * 0.38f, p)
        p.shader = null
    }

    /** botão de pulo: círculo escuro com seta pra cima */
    fun jump(c: Canvas, p: Paint, path: Path, cx: Float, cy: Float, r: Float, pressed: Boolean) {
        p.shader = null; p.style = Paint.Style.FILL
        p.color = if (pressed) Color.argb(230, 90, 90, 90) else Color.argb(200, 25, 25, 25)
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.04f; p.color = Color.argb(230, 235, 235, 235)
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.FILL; p.color = 0xFFE6E6E6.toInt()
        path.reset()
        path.moveTo(cx, cy - r * 0.5f); path.lineTo(cx + r * 0.45f, cy + r * 0.02f); path.lineTo(cx + r * 0.17f, cy + r * 0.02f)
        path.lineTo(cx + r * 0.17f, cy + r * 0.48f); path.lineTo(cx - r * 0.17f, cy + r * 0.48f)
        path.lineTo(cx - r * 0.17f, cy + r * 0.02f); path.lineTo(cx - r * 0.45f, cy + r * 0.02f); path.close()
        c.drawPath(path, p)
    }

    /** botão de chat (balão com três pontinhos) */
    fun chat(c: Canvas, p: Paint, path: Path, rf: RectF, cx: Float, cy: Float, s: Float) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = Color.argb(190, 30, 30, 30)
        rf.set(cx - s, cy - s, cx + s, cy + s)
        c.drawRoundRect(rf, s * 0.15f, s * 0.15f, p)
        p.color = Color.WHITE
        rf.set(cx - s * 0.6f, cy - s * 0.5f, cx + s * 0.6f, cy + s * 0.3f)
        c.drawRoundRect(rf, s * 0.2f, s * 0.2f, p)
        path.reset(); path.moveTo(cx + s * 0.15f, cy + s * 0.25f); path.lineTo(cx + s * 0.55f, cy + s * 0.25f)
        path.lineTo(cx + s * 0.55f, cy + s * 0.65f); path.close(); c.drawPath(path, p)
        p.color = 0xFF2A2A2A.toInt()
        for (k in -1..1) c.drawCircle(cx + k * s * 0.3f, cy - s * 0.1f, s * 0.09f, p)
    }

    fun lock(c: Canvas, p: Paint, rf: RectF, cx: Float, cy: Float, s: Float) {
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.16f; p.color = Color.WHITE
        rf.set(cx - s * 0.4f, cy - s * 0.95f, cx + s * 0.4f, cy - s * 0.05f)
        c.drawArc(rf, 180f, 180f, false, p)
        p.style = Paint.Style.FILL
        rf.set(cx - s * 0.65f, cy - s * 0.3f, cx + s * 0.65f, cy + s * 0.7f)
        c.drawRoundRect(rf, s * 0.15f, s * 0.15f, p)
        p.color = 0xFF222222.toInt(); c.drawCircle(cx, cy + s * 0.2f, s * 0.12f, p)
    }
}
