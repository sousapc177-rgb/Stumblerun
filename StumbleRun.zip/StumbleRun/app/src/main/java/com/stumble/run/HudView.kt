package com.stumble.run

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

class HudView(ctx: Context, private val g: Game) : View(ctx) {
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
        setShadowLayer(8f, 0f, 3f, Color.argb(200, 0, 0, 0))
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private var joyId = -1
    private var cx = 0f; private var cy = 0f
    private var kx = 0f; private var ky = 0f
    private val radius = 130f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val x = e.getX(i); val y = e.getY(i)
                if (g.state == 2 && g.overTimer > 1.5f) { g.restart = true; return true }
                if (x < width * 0.5f) {
                    if (joyId == -1) { joyId = e.getPointerId(i); cx = x; cy = y; kx = x; ky = y }
                } else g.jump = true
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) if (e.getPointerId(i) == joyId) {
                    var dx = e.getX(i) - cx; var dy = e.getY(i) - cy
                    val len = hypot(dx, dy)
                    if (len > radius) { dx = dx / len * radius; dy = dy / len * radius }
                    kx = cx + dx; ky = cy + dy
                    g.inX = dx / radius; g.inZ = dy / radius
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id = e.getPointerId(e.actionIndex)
                if (e.actionMasked == MotionEvent.ACTION_CANCEL || id == joyId) {
                    joyId = -1; g.inX = 0f; g.inZ = 0f
                }
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        text.textSize = h * 0.07f
        c.drawText("Posição ${g.place}/${Game.TOTAL}", w * 0.14f, h * 0.1f, text)
        val sec = g.raceTime.toInt()
        c.drawText("%d:%02d".format(sec / 60, sec % 60), w * 0.5f, h * 0.1f, text)

        if (joyId != -1) {
            fill.color = Color.argb(70, 255, 255, 255); c.drawCircle(cx, cy, radius, fill)
            fill.color = Color.argb(170, 255, 255, 255); c.drawCircle(kx, ky, radius * 0.4f, fill)
        }
        fill.color = Color.argb(110, 255, 200, 40)
        c.drawCircle(w * 0.85f, h * 0.78f, h * 0.13f, fill)
        text.textSize = h * 0.05f
        c.drawText("PULAR", w * 0.85f, h * 0.795f, text)

        if (g.state == 0) {
            text.textSize = h * 0.25f
            val n = Math.ceil((g.countdown - 0.5f).toDouble()).toInt()
            c.drawText(if (n >= 1) "$n" else "VAI!", w / 2, h * 0.5f, text)
        }
        if (g.state == 1 && g.raceTime < 1f) {
            text.textSize = h * 0.2f; c.drawText("VAI!", w / 2, h * 0.5f, text)
        }
        if (g.state == 2) {
            val ok = player() <= Game.QUALIFY
            text.textSize = h * 0.12f
            c.drawText(if (ok) "CLASSIFICADO!" else "ELIMINADO!", w / 2, h * 0.38f, text)
            text.textSize = h * 0.08f
            c.drawText("Você ficou em ${player()}º lugar", w / 2, h * 0.5f, text)
            if (g.overTimer > 1.5f) {
                text.textSize = h * 0.055f
                c.drawText("Toque para jogar de novo", w / 2, h * 0.62f, text)
            }
        }
        postInvalidateOnAnimation()
    }

    private fun player() = g.place
}
