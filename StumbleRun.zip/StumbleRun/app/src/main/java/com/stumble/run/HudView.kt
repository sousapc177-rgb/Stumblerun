package com.stumble.run

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

class HudView(ctx: Context, private val g: Game, private val app: AppState) : View(ctx) {
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
        setShadowLayer(8f, 0f, 3f, Color.argb(200, 0, 0, 0))
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rf = RectF()

    private var joyId = -1; private var camId = -1; private var jumpId = -1
    private var jcx = 0f; private var jcy = 0f      // centro do joystick (dinâmico)
    private var kx = 0f; private var ky = 0f        // bolinha
    private var lastX = 0f
    private var msg: String? = null
    private var msgUntil = 0L
    private var rewardChips = 0
    private var rewardGems = 0
    private var rewardCrown = false

    private fun joyR() = 0.12f * height * app.btnScale
    private fun jumpX() = 0.90f * width
    private fun jumpY() = 0.79f * height
    private fun chatX() = 0.93f * width
    private fun chatY() = 0.50f * height
    private fun chatS() = 0.05f * height * app.btnScale

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (app.mode != 1) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val id = e.getPointerId(i)
                val x = e.getX(i); val y = e.getY(i)
                if (g.state == 2 && g.overTimer > 1.5f) {
                    app.mode = 0; joyId = -1; camId = -1; jumpId = -1
                    g.inX = 0f; g.inZ = 0f; return true
                }
                val jr = 0.12f * height * app.btnScale
                if (hypot(x - jumpX(), y - jumpY()) < jr * 1.3f) {
                    g.jump = true; jumpId = id
                } else if (Math.abs(x - chatX()) < chatS() * 1.3f && Math.abs(y - chatY()) < chatS() * 1.3f) {
                    msg = "Chat em breve!"; msgUntil = System.currentTimeMillis() + 1500
                } else if (x < width * 0.5f) {
                    if (joyId == -1) { joyId = id; jcx = x; jcy = y; kx = x; ky = y }
                } else if (camId == -1) {
                    camId = id; lastX = x
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    if (id == joyId) {
                        var dx = e.getX(i) - jcx; var dy = e.getY(i) - jcy
                        val r = joyR()
                        val len = hypot(dx, dy)
                        if (len > r) { dx = dx / len * r; dy = dy / len * r }
                        kx = jcx + dx; ky = jcy + dy
                        g.inX = dx / r; g.inZ = dy / r
                    } else if (id == camId) {
                        val x = e.getX(i)
                        g.camYaw = (g.camYaw - (x - lastX) * 0.006f).coerceIn(-1.3f, 1.3f)
                        g.camHold = 1.5f
                        lastX = x
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val cancel = e.actionMasked == MotionEvent.ACTION_CANCEL
                val id = e.getPointerId(e.actionIndex)
                if (cancel || id == joyId) { joyId = -1; g.inX = 0f; g.inZ = 0f }
                if (cancel || id == camId) camId = -1
                if (cancel || id == jumpId) jumpId = -1
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        if (app.mode != 1) { postInvalidateOnAnimation(); return }
        val w = width.toFloat(); val h = height.toFloat()

        if (g.state == 2 && !g.rewardClaimed) {
            g.rewardClaimed = true
            val p = g.place
            rewardChips = maxOf(1, 9 - p)
            rewardGems = if (p == 1) 10 else if (p <= Game.QUALIFY) 3 else 0
            rewardCrown = p == 1
            app.chips += rewardChips; app.gems += rewardGems
            if (rewardCrown) app.crowns += 1
            app.save()
        }

        text.textSize = h * 0.07f
        c.drawText("Posição ${g.place}/${Game.TOTAL}", w * 0.14f, h * 0.1f, text)
        val sec = g.raceTime.toInt()
        c.drawText("%d:%02d".format(sec / 60, sec % 60), w * 0.5f, h * 0.1f, text)

        // joystick (aparece onde você encosta; parado fica no canto)
        val r = joyR()
        if (joyId != -1) Icons.joystick(c, fill, path, jcx, jcy, r, kx, ky)
        else Icons.joystick(c, fill, path, 0.11f * w, 0.79f * h, r, 0.11f * w, 0.79f * h)
        // pulo e chat
        Icons.jump(c, fill, path, jumpX(), jumpY(), 0.12f * h * app.btnScale, jumpId != -1)
        Icons.chat(c, fill, path, rf, chatX(), chatY(), chatS())

        if (g.state == 0) {
            text.textSize = h * 0.25f
            val n = Math.ceil((g.countdown - 0.5f).toDouble()).toInt()
            c.drawText(if (n >= 1) "$n" else "VAI!", w / 2, h * 0.5f, text)
        }
        if (g.state == 1 && g.raceTime < 1f) {
            text.textSize = h * 0.2f; c.drawText("VAI!", w / 2, h * 0.5f, text)
        }
        if (g.state == 2) {
            val place = g.place
            val ok = place <= Game.QUALIFY
            text.textSize = h * 0.12f
            c.drawText(if (ok) "CLASSIFICADO!" else "ELIMINADO!", w / 2, h * 0.34f, text)
            text.textSize = h * 0.08f
            c.drawText("Você ficou em ${place}º lugar", w / 2, h * 0.46f, text)
            if (g.overTimer > 1.5f) {
                text.textSize = h * 0.05f
                c.drawText("+$rewardChips fichas   +$rewardGems gemas", w / 2, h * 0.56f, text)
                if (rewardCrown) {
                    Icons.crown(c, fill, path, w * 0.43f, h * 0.65f, h * 0.045f)
                    text.textSize = h * 0.06f
                    c.drawText("+1 coroa!", w * 0.55f, h * 0.67f, text)
                }
                text.textSize = h * 0.045f
                c.drawText("Toque para voltar ao menu", w / 2, h * 0.78f, text)
            }
        }
        val m = msg
        if (m != null && System.currentTimeMillis() < msgUntil) {
            text.textSize = h * 0.055f
            c.drawText(m, w / 2, h * 0.22f, text)
        }
        postInvalidateOnAnimation()
    }
}
