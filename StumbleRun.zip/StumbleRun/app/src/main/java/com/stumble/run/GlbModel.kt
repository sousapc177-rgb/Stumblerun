package com.stumble.run

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.Matrix
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer

/** Carrega o .glb (malha + textura + esqueleto) e calcula os ossos para animar. */
class GlbModel(ctx: Context, file: String) {
    val vertexBuf: FloatBuffer
    val indexBuf: ShortBuffer
    val indexCount: Int
    val texture: Bitmap
    val jointCount: Int
    val nodeCount: Int
    val nodeIndex = HashMap<String, Int>()

    private val parent: IntArray
    private val nT: Array<FloatArray>
    private val nR: Array<FloatArray>
    private val nS: Array<FloatArray>
    private val joints: IntArray
    private val ibm: FloatArray
    private val order = ArrayList<Int>()
    private val world: Array<FloatArray>
    private val local = FloatArray(16)
    private val rot = FloatArray(16)
    private val tmp = FloatArray(16)

    init {
        val data = ctx.assets.open(file).readBytes()
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val jsonLen = bb.getInt(12)
        val json = JSONObject(String(data, 20, jsonLen, Charsets.UTF_8))
        val bin = 20 + jsonLen + 8
        val accessors = json.getJSONArray("accessors")
        val views = json.getJSONArray("bufferViews")

        fun read(ai: Int): FloatArray {
            val a = accessors.getJSONObject(ai)
            val v = views.getJSONObject(a.getInt("bufferView"))
            val comps = when (a.getString("type")) {
                "SCALAR" -> 1; "VEC2" -> 2; "VEC3" -> 3; "VEC4" -> 4; "MAT4" -> 16; else -> 1
            }
            val ct = a.getInt("componentType")
            val size = when (ct) { 5126, 5125 -> 4; 5123, 5122 -> 2; else -> 1 }
            val count = a.getInt("count")
            val norm = a.optBoolean("normalized", false)
            val st = v.optInt("byteStride", 0)
            val stride = if (st == 0) comps * size else st
            val base = bin + v.optInt("byteOffset", 0) + a.optInt("byteOffset", 0)
            val out = FloatArray(count * comps)
            for (i in 0 until count) for (c in 0 until comps) {
                val p = base + i * stride + c * size
                out[i * comps + c] = when (ct) {
                    5126 -> bb.getFloat(p)
                    5125 -> (bb.getInt(p).toLong() and 0xFFFFFFFFL).toFloat()
                    5123 -> { val u = bb.getShort(p).toInt() and 0xFFFF; if (norm) u / 65535f else u.toFloat() }
                    5121 -> { val u = bb.get(p).toInt() and 0xFF; if (norm) u / 255f else u.toFloat() }
                    else -> 0f
                }
            }
            return out
        }

        val prim = json.getJSONArray("meshes").getJSONObject(0)
            .getJSONArray("primitives").getJSONObject(0)
        val at = prim.getJSONObject("attributes")
        val pos = read(at.getInt("POSITION"))
        val nrm = read(at.getInt("NORMAL"))
        val uv = read(at.getInt("TEXCOORD_0"))
        val jn = read(at.getInt("JOINTS_0"))
        val wt = read(at.getInt("WEIGHTS_0"))
        val n = pos.size / 3
        val vb = ByteBuffer.allocateDirect(n * 16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (i in 0 until n) {
            vb.put(pos, i * 3, 3); vb.put(nrm, i * 3, 3); vb.put(uv, i * 2, 2)
            vb.put(jn, i * 4, 4); vb.put(wt, i * 4, 4)
        }
        vb.position(0)
        vertexBuf = vb

        val idx = read(prim.getInt("indices"))
        indexCount = idx.size
        val ib = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
        for (v in idx) ib.put(v.toInt().toShort())
        ib.position(0)
        indexBuf = ib

        // textura (PNG dentro do glb), sem pré-multiplicar o alfa
        val img = json.getJSONArray("images").getJSONObject(0)
        val iv = views.getJSONObject(img.getInt("bufferView"))
        val opts = BitmapFactory.Options()
        opts.inPremultiplied = false
        texture = BitmapFactory.decodeByteArray(
            data, bin + iv.optInt("byteOffset", 0), iv.getInt("byteLength"), opts
        )

        // esqueleto
        val nodes = json.getJSONArray("nodes")
        nodeCount = nodes.length()
        parent = IntArray(nodeCount) { -1 }
        nT = Array(nodeCount) { floatArrayOf(0f, 0f, 0f) }
        nR = Array(nodeCount) { floatArrayOf(0f, 0f, 0f, 1f) }
        nS = Array(nodeCount) { floatArrayOf(1f, 1f, 1f) }
        val kids = Array(nodeCount) { ArrayList<Int>() }
        fun fill(o: JSONObject, key: String, dst: FloatArray) {
            val a = o.optJSONArray(key) ?: return
            for (k in dst.indices) dst[k] = a.getDouble(k).toFloat()
        }
        for (i in 0 until nodeCount) {
            val o = nodes.getJSONObject(i)
            nodeIndex[o.optString("name", "n$i")] = i
            fill(o, "translation", nT[i]); fill(o, "rotation", nR[i]); fill(o, "scale", nS[i])
            val ch = o.optJSONArray("children")
            if (ch != null) for (k in 0 until ch.length()) {
                parent[ch.getInt(k)] = i; kids[i].add(ch.getInt(k))
            }
        }
        fun dfs(i: Int) { order.add(i); for (c in kids[i]) dfs(c) }
        for (i in 0 until nodeCount) if (parent[i] < 0) dfs(i)
        world = Array(nodeCount) { FloatArray(16) }

        val skin = json.getJSONArray("skins").getJSONObject(0)
        val ja = skin.getJSONArray("joints")
        joints = IntArray(ja.length()) { ja.getInt(it) }
        jointCount = joints.size
        ibm = read(skin.getInt("inverseBindMatrices"))
    }

    private fun quatToMat(q: FloatArray, m: FloatArray) {
        val x = q[0]; val y = q[1]; val z = q[2]; val w = q[3]
        m[0] = 1 - 2 * (y * y + z * z); m[1] = 2 * (x * y + z * w); m[2] = 2 * (x * z - y * w); m[3] = 0f
        m[4] = 2 * (x * y - z * w); m[5] = 1 - 2 * (x * x + z * z); m[6] = 2 * (y * z + x * w); m[7] = 0f
        m[8] = 2 * (x * z + y * w); m[9] = 2 * (y * z - x * w); m[10] = 1 - 2 * (x * x + y * y); m[11] = 0f
        m[12] = 0f; m[13] = 0f; m[14] = 0f; m[15] = 1f
    }

    private fun qmul(a: FloatArray, b: FloatArray, out: FloatArray) {
        out[0] = a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1]
        out[1] = a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0]
        out[2] = a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3]
        out[3] = a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]
    }

    private val q = FloatArray(4)

    /** extra[i] = rotação extra (quaternion) aplicada no osso i, ou null. */
    fun computeBones(extra: Array<FloatArray?>, out: FloatArray) {
        for (i in order) {
            val e = extra[i]
            val r = if (e != null) { qmul(nR[i], e, q); q } else nR[i]
            Matrix.setIdentityM(local, 0)
            Matrix.translateM(local, 0, nT[i][0], nT[i][1], nT[i][2])
            quatToMat(r, rot)
            Matrix.multiplyMM(tmp, 0, local, 0, rot, 0)
            System.arraycopy(tmp, 0, local, 0, 16)
            Matrix.scaleM(local, 0, nS[i][0], nS[i][1], nS[i][2])
            if (parent[i] < 0) System.arraycopy(local, 0, world[i], 0, 16)
            else Matrix.multiplyMM(world[i], 0, world[parent[i]], 0, local, 0)
        }
        for (k in joints.indices) Matrix.multiplyMM(out, k * 16, world[joints[k]], 0, ibm, k * 16)
    }
}
