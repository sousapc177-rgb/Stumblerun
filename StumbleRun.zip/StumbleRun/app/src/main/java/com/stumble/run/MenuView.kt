package com.stumble.run

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import kotlin.math.hypot

/** Menu principal (igual ao do Stumble Guys), loja com roleta diária e tela de controles. */
class MenuView(ctx: Context, private val app: AppState, private val game: Game) : View(ctx) {

    private class Prize(val title: String, val value: String, val color: Int,
                        val kind: Int, val amount: Int, val weight: Int, val icon: Int)

    // kind: 0 fichas, 1 gemas, 2 skin Ninja Ryu   |   icon: 0 fichas, 1 gemas, 2 personagem
    private val prizes = arrayOf(
        Prize("Fichas", "1", 0xFFB23AD8.toInt(), 0, 1, 22, 0),
        Prize("Gemas", "10", 0xFF35C238.toInt(), 1, 10, 18, 1),
        Prize("Comum", "5 gemas", 0xFFB59A78.toInt(), 1, 5, 24, 2),
        Prize("Fichas", "5", 0xFFB23AD8.toInt(), 0, 5, 10, 0),
        Prize("Raro", "20 gemas", 0xFF2F8BE6.toInt(), 1, 20, 8, 2),
        Prize("Gemas", "25", 0xFF35C238.toInt(), 1, 25, 6, 1),
        Prize("Fichas", "3", 0xFFB23AD8.toInt(), 0, 3, 10, 0),
        Prize("Épico", "Ninja Ryu", 0xFFF08A1C.toInt(), 2, 60, 4, 2)
    )

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val path = Path()
    private val rf = RectF()

    private var panel = 0   // 0 nenhum, 1 loja, 2 personalizar, 3 social, 4 controles, 5 roleta
    private var wheelAngle = 0f
    private var spinning = false
    private var spinStart = 0L
    private var spinFrom = 0f
    private var spinTo = 0f
    private var spinPrize = 0
    private var resultText: String? = null
    private var dragSlider = false
    private val rnd = java.util.Random()

    private val rSide = RectF(); private val rPlay = RectF()
    private val rName = RectF(); private val rClose = RectF()
    private val rCard0 = RectF(); private val rCard1 = RectF(); private val rShopWheel = RectF()
    private val rNameBtn = RectF(); private val rBack = RectF(); private val rReset = RectF()
    private val rSlider = RectF()
    private var hubX = 0f; private var hubY = 0f; private var hubR = 0f

    // ---------- toques ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (app.mode != 0) return false
        val x = e.x; val y = e.y
        if (dragSlider) {
            if (e.actionMasked == MotionEvent.ACTION_MOVE) { setSlider(x); return true }
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                dragSlider = false; app.save(); return true
            }
        }
        if (e.actionMasked != MotionEvent.ACTION_DOWN) return true
        if (resultText != null) { resultText = null; return true }

        if (panel == 5) {
            if (rClose.contains(x, y)) { if (!spinning) panel = 1 }
            else if (hypot(x - hubX, y - hubY) < hubR) startSpin()
            return true
        }
        if (panel == 4) {
            if (rBack.contains(x, y)) { panel = 0; app.save() }
            else if (rReset.contains(x, y)) { app.btnScale = 1f; app.save() }
            else if (rNameBtn.contains(x, y)) askName()
            else if (x > rSlider.left - width * 0.03f && x < rSlider.right + width * 0.03f &&
                y > rSlider.top - height * 0.05f && y < rSlider.bottom + height * 0.05f) {
                dragSlider = true; setSlider(x)
            }
            return true
        }
        if (panel != 0 && rClose.contains(x, y)) { panel = 0; return true }
        if (rSide.contains(x, y)) {
            val idx = (y / (height / 5f)).toInt().coerceIn(0, 4)
            panel = when (idx) { 0 -> 1; 1 -> 2; 2 -> 0; 3 -> 3; else -> 4 }
            return true
        }
        when (panel) {
            0 -> {
                if (rPlay.contains(x, y)) { game.begin(app.skin); app.mode = 1 }
                else if (rName.contains(x, y)) askName()
            }
            1 -> {
                if (rShopWheel.contains(x, y)) panel = 5
                else if (rCard1.contains(x, y)) buy(1)
            }
            2 -> {
                if (rCard0.contains(x, y) && app.has(0)) { app.skin = 0; app.save() }
                else if (rCard1.contains(x, y) && app.has(1)) { app.skin = 1; app.save() }
            }
        }
        return true
    }

    private fun setSlider(x: Float) {
        val f = ((x - rSlider.left) / rSlider.width()).coerceIn(0f, 1f)
        app.btnScale = 0.7f + 0.7f * f
    }

    private fun buy(i: Int) {
        if (app.has(i)) return
        val price = AppState.SKIN_PRICE[i]
        if (app.gems >= price) {
            app.gems -= price; app.unlock(i); app.save()
            resultText = "Você comprou ${AppState.SKIN_NAMES[i]}!"
        } else {
            resultText = "Faltam ${price - app.gems} gemas"
        }
    }

    private fun askName() {
        val act = context as? Activity ?: return
        val et = EditText(act)
        et.setText(app.name); et.setSingleLine(true)
        AlertDialog.Builder(act).setTitle("Seu nome").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) { app.name = n.take(14); app.save() }
            }
            .setNegativeButton("Cancelar", null).show()
    }

    // ---------- roleta ----------
    private fun startSpin() {
        if (spinning || !app.canSpin()) return
        var total = 0
        for (pr in prizes) total += pr.weight
        var r = rnd.nextInt(total)
        var idx = 0
        for (i in prizes.indices) {
            if (r < prizes[i].weight) { idx = i; break }
            r -= prizes[i].weight
        }
        spinPrize = idx
        spinFrom = wheelAngle
        val delta = (((-idx * 45f - wheelAngle) % 360f) + 360f) % 360f
        spinTo = wheelAngle + 360f * 5f + delta
        spinStart = System.currentTimeMillis()
        spinning = true
    }

    private fun updateSpin() {
        if (!spinning) return
        val k = ((System.currentTimeMillis() - spinStart) / 4500f).coerceIn(0f, 1f)
        val e = 1f - (1f - k) * (1f - k) * (1f - k)
        wheelAngle = spinFrom + (spinTo - spinFrom) * e
        if (k >= 1f) {
            spinning = false
            val pr = prizes[spinPrize]
            when (pr.kind) {
                0 -> { app.chips += pr.amount; resultText = "Você ganhou ${pr.amount} ficha(s)!" }
                1 -> { app.gems += pr.amount; resultText = "Você ganhou ${pr.amount} gemas!" }
                else -> {
                    if (!app.has(1)) { app.unlock(1); resultText = "Você ganhou a skin Ninja Ryu!" }
                    else { app.gems += pr.amount; resultText = "Skin repetida! +${pr.amount} gemas" }
                }
            }
            app.markSpun(); app.save()
        }
    }

    // ---------- desenho ----------
    private fun label(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align) {
        t.textAlign = align; t.textSize = size; t.style = Paint.Style.FILL; t.color = color
        c.drawText(s, x, y, t)
    }

    private fun outlined(c: Canvas, s: String, x: Float, y: Float, size: Float, fill: Int, stroke: Int) {
        t.textAlign = Paint.Align.CENTER; t.textSize = size
        t.style = Paint.Style.STROKE; t.strokeWidth = size * 0.16f; t.color = stroke
        c.drawText(s, x, y, t)
        t.style = Paint.Style.FILL; t.color = fill
        c.drawText(s, x, y, t)
    }

    private fun roundRect(c: Canvas, r: RectF, rad: Float, color: Int) {
        p.style = Paint.Style.FILL; p.shader = null; p.color = color
        c.drawRoundRect(r, rad, rad, p)
    }

    override fun onDraw(c: Canvas) {
        if (app.mode != 0) { postInvalidateOnAnimation(); return }
        val w = width.toFloat(); val h = height.toFloat()
        updateSpin()
        val sbW = w * 0.155f
        rSide.set(0f, 0f, sbW, h)

        if (panel == 4) {
            drawControls(c, w, h)
        } else {
            drawTopBar(c, w, h, sbW)
            drawSidebar(c, w, h, sbW)
            if (panel == 0) { drawPlay(c, w, h); drawLevel(c, w, h) }
            when (panel) {
                1 -> drawShop(c, w, h)
                2 -> drawCustomize(c, w, h)
                3 -> simplePanel(c, w, h, "Social", "Em breve!")
                5 -> drawWheel(c, w, h)
            }
        }
        val rt = resultText
        if (rt != null) {
            p.shader = null; p.style = Paint.Style.FILL; p.color = Color.argb(150, 0, 0, 0)
            c.drawRect(0f, 0f, w, h, p)
            rf.set(w * 0.28f, h * 0.32f, w * 0.72f, h * 0.68f)
            roundRect(c, rf, h * 0.04f, 0xFFFFFFFF.toInt())
            label(c, rt, w / 2, h * 0.5f, h * 0.06f, 0xFF1B2A4A.toInt(), Paint.Align.CENTER)
            label(c, "Toque para continuar", w / 2, h * 0.61f, h * 0.04f, 0xFF6B7A99.toInt(), Paint.Align.CENTER)
        }
        postInvalidateOnAnimation()
    }

    private fun counter(c: Canvas, x0: Float, x1: Float, h: Float, value: Int, icon: Int) {
        rf.set(x0, h * 0.018f, x1, h * 0.078f)
        roundRect(c, rf, h * 0.03f, 0xFF0D2459.toInt())
        val ix = x0 + h * 0.04f; val iy = h * 0.048f
        when (icon) {
            0 -> Icons.crown(c, p, path, ix, iy, h * 0.03f)
            1 -> {
                p.shader = null; p.style = Paint.Style.FILL
                p.color = 0xFFB23AD8.toInt(); c.drawCircle(ix, iy, h * 0.03f, p)
                p.color = 0xFFE9A6FF.toInt(); c.drawCircle(ix, iy, h * 0.017f, p)
            }
            else -> Icons.gem(c, p, path, ix, iy, h * 0.034f)
        }
        label(c, value.toString(), x1 - h * 0.015f, h * 0.064f, h * 0.045f, Color.WHITE, Paint.Align.RIGHT)
    }

    private fun drawTopBar(c: Canvas, w: Float, h: Float, sbW: Float) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = 0xFF1B49A0.toInt()
        c.drawRect(sbW, 0f, w, h * 0.095f, p)
        label(c, app.name, sbW + w * 0.03f, h * 0.065f, h * 0.048f, Color.WHITE, Paint.Align.LEFT)
        val nameW = t.measureText(app.name)
        label(c, "✎", sbW + w * 0.03f + nameW + w * 0.02f, h * 0.065f, h * 0.05f, 0xFFBFD4FF.toInt(), Paint.Align.LEFT)
        rName.set(sbW, 0f, sbW + w * 0.03f + nameW + w * 0.06f, h * 0.095f)
        counter(c, w * 0.45f, w * 0.60f, h, app.crowns, 0)
        counter(c, w * 0.62f, w * 0.78f, h, app.chips, 1)
        counter(c, w * 0.80f, w * 0.97f, h, app.gems, 2)
    }

    private fun drawLevel(c: Canvas, w: Float, h: Float) {
        Icons.crown(c, p, path, w * 0.43f, h * 0.915f, h * 0.035f)
        label(c, "Nível ${app.level()} • ${app.crowns} coroa(s)", w * 0.465f, h * 0.935f, h * 0.045f, Color.WHITE, Paint.Align.LEFT)
    }

    private fun drawSidebar(c: Canvas, w: Float, h: Float, sbW: Float) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = 0xFF202B45.toInt()
        c.drawRect(0f, 0f, sbW, h, p)
        val names = arrayOf("Loja", "Personalizar", "Play", "Social", "Config.")
        val sel = if (panel == 0) 2 else when (panel) { 1 -> 0; 5 -> 0; 2 -> 1; 3 -> 3; else -> 4 }
        val ih = h / 5f
        for (i in 0 until 5) {
            val top = i * ih
            if (i == sel) { p.color = 0xFF2C6BD6.toInt(); c.drawRect(0f, top, sbW, top + ih, p) }
            p.color = 0xFF121A2E.toInt(); c.drawRect(0f, top + ih - 2f, sbW, top + ih, p)
            drawIcon(c, i, sbW / 2, top + ih * 0.38f, ih * 0.2f)
            label(c, names[i], sbW / 2, top + ih * 0.85f, h * 0.036f, Color.WHITE, Paint.Align.CENTER)
        }
        if (app.canSpin()) {
            p.color = 0xFFE53935.toInt(); c.drawCircle(sbW * 0.78f, ih * 0.2f, h * 0.025f, p)
            label(c, "!", sbW * 0.78f, ih * 0.2f + h * 0.012f, h * 0.034f, Color.WHITE, Paint.Align.CENTER)
        }
    }

    private fun drawIcon(c: Canvas, i: Int, cx: Float, cy: Float, r: Float) {
        p.shader = null; p.color = Color.WHITE; p.style = Paint.Style.FILL
        when (i) {
            0 -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.22f; p.strokeCap = Paint.Cap.ROUND
                path.reset(); path.moveTo(cx - r, cy - r * 0.8f); path.lineTo(cx - r * 0.55f, cy - r * 0.8f)
                path.lineTo(cx - r * 0.2f, cy + r * 0.4f); path.lineTo(cx + r * 0.8f, cy + r * 0.4f)
                path.lineTo(cx + r, cy - r * 0.4f); path.lineTo(cx - r * 0.5f, cy - r * 0.4f)
                c.drawPath(path, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx - r * 0.1f, cy + r * 0.85f, r * 0.2f, p)
                c.drawCircle(cx + r * 0.65f, cy + r * 0.85f, r * 0.2f, p)
            }
            1 -> {
                c.drawCircle(cx, cy, r, p)
                p.color = 0xFF202B45.toInt()
                c.drawCircle(cx - r * 0.35f, cy - r * 0.1f, r * 0.14f, p)
                c.drawCircle(cx + r * 0.35f, cy - r * 0.1f, r * 0.14f, p)
                rf.set(cx - r * 0.3f, cy + r * 0.25f, cx + r * 0.3f, cy + r * 0.5f)
                c.drawRoundRect(rf, r * 0.1f, r * 0.1f, p)
            }
            2 -> {
                path.reset(); path.moveTo(cx - r * 0.7f, cy - r); path.lineTo(cx + r * 0.9f, cy); path.lineTo(cx - r * 0.7f, cy + r); path.close()
                c.drawPath(path, p)
            }
            3 -> {
                rf.set(cx - r, cy - r * 0.8f, cx + r, cy + r * 0.6f)
                c.drawRoundRect(rf, r * 0.4f, r * 0.4f, p)
                path.reset(); path.moveTo(cx - r * 0.4f, cy + r * 0.5f); path.lineTo(cx - r * 0.6f, cy + r * 1.1f); path.lineTo(cx, cy + r * 0.5f); path.close()
                c.drawPath(path, p)
            }
            else -> {
                for (k in 0 until 8) {
                    c.save(); c.rotate(k * 45f, cx, cy)
                    rf.set(cx - r * 0.18f, cy - r * 1.0f, cx + r * 0.18f, cy - r * 0.6f)
                    c.drawRect(rf, p); c.restore()
                }
                c.drawCircle(cx, cy, r * 0.75f, p)
                p.color = 0xFF202B45.toInt(); c.drawCircle(cx, cy, r * 0.3f, p)
            }
        }
        p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
    }

    private fun drawPlay(c: Canvas, w: Float, h: Float) {
        rPlay.set(w * 0.735f, h * 0.76f, w * 0.975f, h * 0.94f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, rPlay.top, 0f, rPlay.bottom, 0xFFFFD43B.toInt(), 0xFFF0A100.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(rPlay, h * 0.012f, h * 0.012f, p)
        p.shader = null
        c.save(); c.clipRect(rPlay)
        p.color = Color.argb(60, 255, 255, 255)
        for (k in 0 until 2) {
            val x0 = rPlay.left + rPlay.width() * (0.15f + k * 0.5f)
            path.reset(); path.moveTo(x0, rPlay.bottom); path.lineTo(x0 + rPlay.width() * 0.2f, rPlay.bottom)
            path.lineTo(x0 + rPlay.width() * 0.5f, rPlay.top); path.lineTo(x0 + rPlay.width() * 0.3f, rPlay.top); path.close()
            c.drawPath(path, p)
        }
        c.restore()
        p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.008f; p.color = 0xFF8A4B00.toInt()
        c.drawRoundRect(rPlay, h * 0.012f, h * 0.012f, p)
        p.style = Paint.Style.FILL
        outlined(c, "Play", rPlay.centerX(), rPlay.centerY() + h * 0.04f, h * 0.115f, Color.WHITE, 0xFF4A2A00.toInt())
    }

    private fun closeButton(c: Canvas, cx: Float, cy: Float, r: Float) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = 0xFFE53935.toInt()
        c.drawCircle(cx, cy, r, p)
        label(c, "X", cx, cy + r * 0.35f, r * 1.0f, Color.WHITE, Paint.Align.CENTER)
        rClose.set(cx - r * 1.4f, cy - r * 1.4f, cx + r * 1.4f, cy + r * 1.4f)
    }

    private fun simplePanel(c: Canvas, w: Float, h: Float, title: String, msg: String) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = Color.argb(130, 0, 0, 0)
        c.drawRect(w * 0.155f, h * 0.095f, w, h, p)
        rf.set(w * 0.25f, h * 0.2f, w * 0.85f, h * 0.8f)
        roundRect(c, rf, h * 0.04f, 0xFF223A6B.toInt())
        label(c, title, rf.centerX(), h * 0.33f, h * 0.075f, Color.WHITE, Paint.Align.CENTER)
        label(c, msg, rf.centerX(), h * 0.55f, h * 0.06f, 0xFFBFD4FF.toInt(), Paint.Align.CENTER)
        closeButton(c, rf.right - h * 0.03f, rf.top + h * 0.03f, h * 0.035f)
    }

    private fun silhouette(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = color
        c.drawCircle(cx, cy - s * 0.25f, s * 0.28f, p)
        rf.set(cx - s * 0.4f, cy, cx + s * 0.4f, cy + s * 0.75f)
        c.drawRoundRect(rf, s * 0.2f, s * 0.2f, p)
    }

    private fun drawShop(c: Canvas, w: Float, h: Float) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = Color.argb(130, 0, 0, 0)
        c.drawRect(w * 0.155f, h * 0.095f, w, h, p)
        rf.set(w * 0.17f, h * 0.12f, w * 0.99f, h * 0.97f)
        roundRect(c, rf, h * 0.03f, Color.argb(240, 20, 40, 90))
        label(c, "Loja", w * 0.2f, h * 0.21f, h * 0.06f, Color.WHITE, Paint.Align.LEFT)
        closeButton(c, w * 0.965f, h * 0.17f, h * 0.035f)

        // roleta diária
        rShopWheel.set(w * 0.20f, h * 0.27f, w * 0.40f, h * 0.92f)
        roundRect(c, rShopWheel, h * 0.025f, 0xFF7A3FE0.toInt())
        val cx = rShopWheel.centerX(); val cy = rShopWheel.top + h * 0.17f; val r = h * 0.09f
        val cols = intArrayOf(0xFF35C238.toInt(), 0xFFB23AD8.toInt(), 0xFF2F8BE6.toInt(), 0xFFF08A1C.toInt())
        rf.set(cx - r, cy - r, cx + r, cy + r)
        p.style = Paint.Style.FILL
        for (k in 0 until 4) { p.color = cols[k]; c.drawArc(rf, k * 90f, 90f, true, p) }
        p.color = Color.WHITE; c.drawCircle(cx, cy, r * 0.22f, p)
        label(c, "Roleta diária", cx, rShopWheel.top + h * 0.34f, h * 0.045f, Color.WHITE, Paint.Align.CENTER)
        rf.set(rShopWheel.left + w * 0.015f, rShopWheel.bottom - h * 0.19f, rShopWheel.right - w * 0.015f, rShopWheel.bottom - h * 0.06f)
        roundRect(c, rf, h * 0.025f, if (app.canSpin()) 0xFF35C238.toInt() else 0xFF6B6F85.toInt())
        label(c, if (app.canSpin()) "GRÁTIS!" else "Volte amanhã", rf.centerX(), rf.centerY() + h * 0.017f, h * 0.042f, Color.WHITE, Paint.Align.CENTER)
        if (app.canSpin()) {
            p.color = 0xFFE53935.toInt(); c.drawCircle(rShopWheel.right - h * 0.02f, rShopWheel.top + h * 0.02f, h * 0.027f, p)
            label(c, "!", rShopWheel.right - h * 0.02f, rShopWheel.top + h * 0.032f, h * 0.036f, Color.WHITE, Paint.Align.CENTER)
        }

        // skins
        for (i in 0 until 2) {
            val rr = if (i == 0) rCard0 else rCard1
            val x0 = w * 0.43f + i * (w * 0.23f)
            rr.set(x0, h * 0.27f, x0 + w * 0.20f, h * 0.92f)
            roundRect(c, rr, h * 0.025f, if (i == 0) 0xFFB59A78.toInt() else 0xFFF08A1C.toInt())
            label(c, AppState.SKIN_RARITY[i], rr.centerX(), rr.top + h * 0.06f, h * 0.04f, Color.WHITE, Paint.Align.CENTER)
            label(c, AppState.SKIN_NAMES[i], rr.centerX(), rr.top + h * 0.12f, h * 0.048f, Color.WHITE, Paint.Align.CENTER)
            silhouette(c, rr.centerX(), rr.top + h * 0.3f, h * 0.2f, Color.argb(120, 20, 20, 40))
            rf.set(rr.left + w * 0.015f, rr.bottom - h * 0.19f, rr.right - w * 0.015f, rr.bottom - h * 0.06f)
            if (app.has(i)) {
                roundRect(c, rf, h * 0.025f, Color.argb(150, 0, 0, 0))
                label(c, "Possuído ✓", rf.centerX(), rf.centerY() + h * 0.017f, h * 0.042f, Color.WHITE, Paint.Align.CENTER)
            } else {
                roundRect(c, rf, h * 0.025f, if (app.gems >= AppState.SKIN_PRICE[i]) 0xFF35C238.toInt() else 0xFF6B6F85.toInt())
                Icons.gem(c, p, path, rf.left + h * 0.05f, rf.centerY(), h * 0.04f)
                label(c, AppState.SKIN_PRICE[i].toString(), rf.centerX() + h * 0.03f, rf.centerY() + h * 0.02f, h * 0.05f, Color.WHITE, Paint.Align.CENTER)
            }
        }
    }

    private fun drawCustomize(c: Canvas, w: Float, h: Float) {
        rf.set(w * 0.17f, h * 0.57f, w * 0.995f, h * 0.99f)
        roundRect(c, rf, h * 0.03f, Color.argb(235, 20, 40, 90))
        label(c, "Personalizar", w * 0.2f, h * 0.66f, h * 0.05f, Color.WHITE, Paint.Align.LEFT)
        closeButton(c, w * 0.965f, h * 0.635f, h * 0.035f)
        val cw = w * 0.2f
        for (i in 0 until 2) {
            val r = if (i == 0) rCard0 else rCard1
            r.set(w * 0.2f + i * (cw + w * 0.03f), h * 0.7f, w * 0.2f + i * (cw + w * 0.03f) + cw, h * 0.96f)
            val owned = app.has(i)
            roundRect(c, r, h * 0.025f, if (!owned) 0xFF4A4F66.toInt() else if (i == 0) 0xFFB59A78.toInt() else 0xFFF08A1C.toInt())
            if (app.skin == i) {
                p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.01f; p.color = Color.WHITE
                c.drawRoundRect(r, h * 0.025f, h * 0.025f, p); p.style = Paint.Style.FILL
            }
            label(c, AppState.SKIN_RARITY[i], r.centerX(), r.top + h * 0.06f, h * 0.045f, Color.WHITE, Paint.Align.CENTER)
            label(c, AppState.SKIN_NAMES[i], r.centerX(), r.top + h * 0.13f, h * 0.055f, Color.WHITE, Paint.Align.CENTER)
            if (!owned) {
                Icons.lock(c, p, rf, r.right - h * 0.06f, r.top + h * 0.1f, h * 0.035f)
                label(c, "Na Loja", r.centerX(), r.bottom - h * 0.04f, h * 0.04f, 0xFFD0D6EA.toInt(), Paint.Align.CENTER)
            } else {
                label(c, if (app.skin == i) "Equipado ✓" else "Equipar", r.centerX(), r.bottom - h * 0.04f, h * 0.04f,
                    if (app.skin == i) 0xFFFFFFFF.toInt() else 0xFF3A2A10.toInt(), Paint.Align.CENTER)
            }
        }
    }

    /** tela de controles, igual ao print */
    private fun drawControls(c: Canvas, w: Float, h: Float) {
        p.shader = null; p.style = Paint.Style.FILL
        p.color = 0xFF3C3C3C.toInt(); c.drawRect(0f, 0f, w * 0.5f, h, p)
        p.color = 0xFF2B2B2B.toInt(); c.drawRect(w * 0.5f, 0f, w, h, p)

        // voltar
        rBack.set(w * 0.022f, h * 0.035f, w * 0.086f, h * 0.12f)
        roundRect(c, rBack, h * 0.012f, 0xFFE53935.toInt())
        p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.016f; p.color = Color.WHITE; p.strokeCap = Paint.Cap.ROUND
        path.reset(); path.moveTo(rBack.centerX() + h * 0.02f, rBack.centerY() - h * 0.03f)
        path.lineTo(rBack.centerX() - h * 0.015f, rBack.centerY()); path.lineTo(rBack.centerX() + h * 0.02f, rBack.centerY() + h * 0.03f)
        c.drawPath(path, p)
        p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
        // reiniciar
        rReset.set(w * 0.864f, h * 0.03f, w * 0.98f, h * 0.125f)
        roundRect(c, rReset, h * 0.012f, 0xFFFFC62D.toInt())
        outlined(c, "Reiniciar", rReset.centerX(), rReset.centerY() + h * 0.02f, h * 0.05f, Color.WHITE, 0xFF4A2A00.toInt())
        // mudar nome
        rNameBtn.set(w * 0.40f, h * 0.035f, w * 0.60f, h * 0.12f)
        roundRect(c, rNameBtn, h * 0.012f, 0xFF2C6BD6.toInt())
        label(c, "Mudar nome", rNameBtn.centerX(), rNameBtn.centerY() + h * 0.018f, h * 0.045f, Color.WHITE, Paint.Align.CENTER)

        // barra de tamanho
        outlined(c, "Tamanho do", w * 0.30f, h * 0.215f, h * 0.05f, Color.WHITE, 0xFF000000.toInt())
        outlined(c, "botão", w * 0.34f, h * 0.285f, h * 0.05f, Color.WHITE, 0xFF000000.toInt())
        rSlider.set(w * 0.395f, h * 0.19f, w * 0.793f, h * 0.25f)
        roundRect(c, rSlider, h * 0.012f, 0xFF000000.toInt())
        val f = ((app.btnScale - 0.7f) / 0.7f).coerceIn(0f, 1f)
        val hx = rSlider.left + rSlider.width() * f
        rf.set(rSlider.left, rSlider.top + h * 0.006f, hx, rSlider.bottom - h * 0.006f)
        roundRect(c, rf, h * 0.01f, 0xFFFFC62D.toInt())
        rf.set(hx - w * 0.018f, rSlider.top - h * 0.025f, hx + w * 0.018f, rSlider.bottom + h * 0.025f)
        roundRect(c, rf, h * 0.01f, 0xFFFFB300.toInt())
        p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.006f; p.color = 0xFF7A4B00.toInt()
        c.drawRoundRect(rf, h * 0.01f, h * 0.01f, p); p.style = Paint.Style.FILL

        // áreas
        p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.006f; p.color = 0xFFD32F2F.toInt()
        rf.set(0f, h * 0.31f, w * 0.5f, h * 0.995f); c.drawRect(rf, p)
        rf.set(w * 0.5f, h * 0.31f, w * 0.998f, h * 0.995f); c.drawRect(rf, p)
        p.style = Paint.Style.FILL
        outlined(c, "Área dinâmica do botão direcional", w * 0.25f, h * 0.385f, h * 0.045f, 0xFFFF6B6B.toInt(), 0xFF3A0000.toInt())
        outlined(c, "Área de controle da câmera", w * 0.75f, h * 0.39f, h * 0.045f, 0xFFFF6B6B.toInt(), 0xFF3A0000.toInt())

        // exemplos de botões (mudam com a barra)
        val s = app.btnScale
        val jr = 0.12f * h * s
        Icons.joystick(c, p, path, 0.11f * w, 0.79f * h, jr, 0.11f * w, 0.79f * h)
        Icons.jump(c, p, path, 0.90f * w, 0.79f * h, jr, false)
        Icons.chat(c, p, path, rf, 0.93f * w, 0.50f * h, 0.05f * h * s)
    }

    private fun drawWheel(c: Canvas, w: Float, h: Float) {
        p.shader = LinearGradient(0f, 0f, 0f, h, 0xFF3E8EEA.toInt(), 0xFF123A86.toInt(), Shader.TileMode.CLAMP)
        p.style = Paint.Style.FILL
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        rf.set(w * 0.32f, h * 0.025f, w * 0.68f, h * 0.15f)
        roundRect(c, rf, h * 0.035f, Color.WHITE)
        label(c, "RODADA SORTUDA", w / 2, h * 0.105f, h * 0.06f, 0xFF1B2A4A.toInt(), Paint.Align.CENTER)
        rf.set(w * 0.4f, h * 0.15f, w * 0.6f, h * 0.2f)
        roundRect(c, rf, h * 0.02f, 0xFFCDBFA8.toInt())
        label(c, "Comum ou Melhor", w / 2, h * 0.187f, h * 0.034f, 0xFF4A3F2E.toInt(), Paint.Align.CENTER)
        closeButton(c, w * 0.955f, h * 0.075f, h * 0.04f)

        val cx = w / 2; val cy = h * 1.0f; val R = h * 0.70f
        c.save(); c.rotate(wheelAngle, cx, cy)
        rf.set(cx - R, cy - R, cx + R, cy + R)
        for (i in prizes.indices) {
            c.save(); c.rotate(i * 45f, cx, cy)
            val pr = prizes[i]
            p.style = Paint.Style.FILL; p.color = pr.color
            c.drawArc(rf, -90f - 22.5f, 45f, true, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.006f; p.color = Color.argb(120, 255, 255, 255)
            c.drawArc(rf, -90f - 22.5f, 45f, true, p)
            p.style = Paint.Style.FILL
            label(c, pr.title, cx, cy - R * 0.9f, h * 0.04f, Color.WHITE, Paint.Align.CENTER)
            prizeIcon(c, pr.icon, cx, cy - R * 0.72f, h * 0.075f)
            val big = pr.value.length <= 2
            label(c, pr.value, cx, cy - R * (if (big) 0.52f else 0.54f), if (big) h * 0.07f else h * 0.04f, Color.WHITE, Paint.Align.CENTER)
            c.restore()
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.04f; p.color = 0xFF2D6FD1.toInt()
        c.drawCircle(cx, cy, R + h * 0.018f, p)
        p.style = Paint.Style.FILL
        for (i in 0 until 8) {
            c.save(); c.rotate(i * 45f + 22.5f, cx, cy)
            p.color = 0xFFFFF3B0.toInt(); c.drawCircle(cx, cy - R - h * 0.018f, h * 0.014f, p)
            c.restore()
        }
        c.restore()

        p.color = 0xFFE53935.toInt()
        c.drawCircle(cx, cy - R - h * 0.05f, h * 0.04f, p)
        path.reset(); path.moveTo(cx - h * 0.034f, cy - R - h * 0.035f); path.lineTo(cx + h * 0.034f, cy - R - h * 0.035f)
        path.lineTo(cx, cy - R + h * 0.015f); path.close(); c.drawPath(path, p)
        p.color = Color.WHITE; c.drawCircle(cx, cy - R - h * 0.05f, h * 0.014f, p)

        hubX = cx; hubY = cy; hubR = h * 0.15f
        val can = app.canSpin() && !spinning
        p.color = if (can) 0xFFFFC62D.toInt() else 0xFF8896B3.toInt()
        c.drawCircle(hubX, hubY, hubR, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.008f; p.color = Color.WHITE
        c.drawCircle(hubX, hubY, hubR, p); p.style = Paint.Style.FILL
        if (can) outlined(c, "GIRAR", cx, h * 0.935f, h * 0.06f, Color.WHITE, 0xFF4A2A00.toInt())
        else if (spinning) label(c, "...", cx, h * 0.94f, h * 0.06f, Color.WHITE, Paint.Align.CENTER)
        else label(c, "Volte amanhã", cx, h * 0.94f, h * 0.04f, Color.WHITE, Paint.Align.CENTER)
    }

    private fun prizeIcon(c: Canvas, kind: Int, cx: Float, cy: Float, s: Float) {
        p.style = Paint.Style.FILL
        when (kind) {
            0 -> for (k in 0 until 3) {
                rf.set(cx - s * 0.7f + k * s * 0.15f, cy + s * 0.25f - k * s * 0.28f, cx + s * 0.1f + k * s * 0.15f, cy + s * 0.55f - k * s * 0.28f)
                p.color = 0xFF7A1F99.toInt(); c.drawOval(rf, p)
                rf.offset(0f, -s * 0.06f); p.color = 0xFFE9A6FF.toInt(); c.drawOval(rf, p)
            }
            1 -> {
                Icons.gem(c, p, path, cx - s * 0.35f, cy + s * 0.1f, s * 0.38f)
                Icons.gem(c, p, path, cx + s * 0.35f, cy, s * 0.4f)
                Icons.gem(c, p, path, cx, cy + s * 0.3f, s * 0.42f)
            }
            else -> silhouette(c, cx, cy, s * 1.1f, Color.argb(200, 30, 30, 50))
        }
    }
}
