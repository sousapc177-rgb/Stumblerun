package com.stumble.run

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import kotlin.math.hypot

/** Menu principal igual ao do Stumble Guys + roleta diária. */
class MenuView(ctx: Context, private val app: AppState, private val game: Game) : View(ctx) {

    private class Prize(val title: String, val value: String, val color: Int,
                        val kind: Int, val amount: Int, val weight: Int, val icon: Int)

    // icon: 0 fichas, 1 gemas, 2 personagem
    private val prizes = arrayOf(
        Prize("Fichas", "1", 0xFFB23AD8.toInt(), 0, 1, 22, 0),
        Prize("Gemas", "10", 0xFF35C238.toInt(), 1, 10, 18, 1),
        Prize("Comum", "5 gemas", 0xFFB59A78.toInt(), 1, 5, 24, 2),
        Prize("Fichas", "5", 0xFFB23AD8.toInt(), 0, 5, 10, 0),
        Prize("Raro", "20 gemas", 0xFF2F8BE6.toInt(), 1, 20, 8, 2),
        Prize("Gemas", "25", 0xFF35C238.toInt(), 1, 25, 6, 1),
        Prize("Fichas", "3", 0xFFB23AD8.toInt(), 0, 3, 10, 0),
        Prize("Épico", "60 gemas", 0xFFF08A1C.toInt(), 1, 60, 2, 2)
    )

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val path = Path()
    private val rf = RectF()

    private var panel = 0   // 0 nenhum, 1 loja, 2 personalizar, 3 social, 4 config, 5 roleta
    private var wheelAngle = 0f
    private var spinning = false
    private var spinStart = 0L
    private var spinFrom = 0f
    private var spinTo = 0f
    private var spinPrize = 0
    private var resultText: String? = null
    private val rnd = java.util.Random()

    // áreas clicáveis (atualizadas a cada desenho)
    private val rSide = RectF(); private val rPlay = RectF(); private val rWheelBtn = RectF()
    private val rName = RectF(); private val rClose = RectF()
    private val rCard0 = RectF(); private val rCard1 = RectF(); private val rNameBtn = RectF()
    private var hubX = 0f; private var hubY = 0f; private var hubR = 0f

    // ---------- toques ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (app.mode != 0) return false
        if (e.actionMasked != MotionEvent.ACTION_DOWN) return true
        val x = e.x; val y = e.y
        if (resultText != null) { resultText = null; return true }
        if (panel == 5) {
            if (rClose.contains(x, y)) { if (!spinning) panel = 0 }
            else if (hypot(x - hubX, y - hubY) < hubR) startSpin()
            return true
        }
        if (panel != 0 && rClose.contains(x, y)) { panel = 0; return true }
        if (rSide.contains(x, y)) {
            val idx = (y / (height / 5f)).toInt().coerceIn(0, 4)
            panel = when (idx) { 0 -> 1; 1 -> 2; 2 -> 0; 3 -> 3; else -> 4 }
            return true
        }
        when (panel) {
            0 -> {
                if (rPlay.contains(x, y)) { game.begin(app.skin); app.mode = 1 }
                else if (rWheelBtn.contains(x, y)) panel = 5
                else if (rName.contains(x, y)) askName()
            }
            2 -> {
                if (rCard0.contains(x, y)) { app.skin = 0; app.save() }
                else if (rCard1.contains(x, y)) { app.skin = 1; app.save() }
            }
            4 -> if (rNameBtn.contains(x, y)) askName()
        }
        return true
    }

    private fun askName() {
        val act = context as? Activity ?: return
        val et = EditText(act)
        et.setText(app.name); et.setSingleLine(true)
        AlertDialog.Builder(act).setTitle("Seu nome").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) { app.name = n.take(14); app.save() }
            }
            .setNegativeButton("Cancelar", null).show()
    }

    // ---------- roleta ----------
    private fun startSpin() {
        if (spinning || !app.canSpin()) return
        var total = 0
        for (pr in prizes) total += pr.weight
        var r = rnd.nextInt(total)
        var idx = 0
        for (i in prizes.indices) {
            if (r < prizes[i].weight) { idx = i; break }
            r -= prizes[i].weight
        }
        spinPrize = idx
        spinFrom = wheelAngle
        val delta = (((-idx * 45f - wheelAngle) % 360f) + 360f) % 360f
        spinTo = wheelAngle + 360f * 5f + delta
        spinStart = System.currentTimeMillis()
        spinning = true
    }

    private fun updateSpin() {
        if (!spinning) return
        val k = ((System.currentTimeMillis() - spinStart) / 4500f).coerceIn(0f, 1f)
        val e = 1f - (1f - k) * (1f - k) * (1f - k)
        wheelAngle = spinFrom + (spinTo - spinFrom) * e
        if (k >= 1f) {
            spinning = false
            val pr = prizes[spinPrize]
            if (pr.kind == 0) app.chips += pr.amount else app.gems += pr.amount
            app.markSpun(); app.save()
            resultText = if (pr.kind == 0) "Você ganhou ${pr.amount} ficha(s)!" else "Você ganhou ${pr.amount} gemas!"
        }
    }

    // ---------- desenho ----------
    private fun label(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align) {
        t.textAlign = align; t.textSize = size; t.style = Paint.Style.FILL; t.color = color
        c.drawText(s, x, y, t)
    }

    private fun outlined(c: Canvas, s: String, x: Float, y: Float, size: Float, fill: Int, stroke: Int) {
        t.textAlign = Paint.Align.CENTER; t.textSize = size
        t.style = Paint.Style.STROKE; t.strokeWidth = size * 0.16f; t.color = stroke
        c.drawText(s, x, y, t)
        t.style = Paint.Style.FILL; t.color = fill
        c.drawText(s, x, y, t)
    }

    private fun roundRect(c: Canvas, r: RectF, rad: Float, color: Int) {
        p.style = Paint.Style.FILL; p.shader = null; p.color = color
        c.drawRoundRect(r, rad, rad, p)
    }

    override fun onDraw(c: Canvas) {
        if (app.mode != 0) { postInvalidateOnAnimation(); return }
        val w = width.toFloat(); val h = height.toFloat()
        updateSpin()
        val sbW = w * 0.155f
        rSide.set(0f, 0f, sbW, h)

        drawTopBar(c, w, h, sbW)
        drawSidebar(c, w, h, sbW)
        if (panel == 0) { drawPlay(c, w, h); drawWheelButton(c, w, h) }
        when (panel) {
            1 -> simplePanel(c, w, h, "Loja", "Em breve!")
            2 -> drawCustomize(c, w, h)
            3 -> simplePanel(c, w, h, "Social", "Em breve!")
            4 -> drawSettings(c, w, h)
            5 -> drawWheel(c, w, h)
        }
        val rt = resultText
        if (rt != null) {
            p.shader = null; p.style = Paint.Style.FILL; p.color = Color.argb(150, 0, 0, 0)
            c.drawRect(0f, 0f, w, h, p)
            rf.set(w * 0.28f, h * 0.32f, w * 0.72f, h * 0.68f)
            roundRect(c, rf, h * 0.04f, 0xFFFFFFFF.toInt())
            label(c, rt, w / 2, h * 0.5f, h * 0.06f, 0xFF1B2A4A.toInt(), Paint.Align.CENTER)
            label(c, "Toque para continuar", w / 2, h * 0.61f, h * 0.04f, 0xFF6B7A99.toInt(), Paint.Align.CENTER)
        }
        postInvalidateOnAnimation()
    }

    private fun drawTopBar(c: Canvas, w: Float, h: Float, sbW: Float) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = 0xFF1B49A0.toInt()
        c.drawRect(sbW, 0f, w, h * 0.095f, p)
        label(c, app.name, sbW + w * 0.03f, h * 0.065f, h * 0.048f, Color.WHITE, Paint.Align.LEFT)
        val nameW = t.measureText(app.name)
        label(c, "✎", sbW + w * 0.03f + nameW + w * 0.02f, h * 0.065f, h * 0.05f, 0xFFBFD4FF.toInt(), Paint.Align.LEFT)
        rName.set(sbW, 0f, sbW + w * 0.03f + nameW + w * 0.06f, h * 0.095f)

        // gemas
        rf.set(w * 0.80f, h * 0.018f, w * 0.97f, h * 0.078f)
        roundRect(c, rf, h * 0.03f, 0xFF0D2459.toInt())
        gem(c, w * 0.815f, h * 0.048f, h * 0.034f)
        label(c, app.gems.toString(), w * 0.96f, h * 0.064f, h * 0.045f, Color.WHITE, Paint.Align.RIGHT)
        // fichas
        rf.set(w * 0.62f, h * 0.018f, w * 0.78f, h * 0.078f)
        roundRect(c, rf, h * 0.03f, 0xFF0D2459.toInt())
        p.color = 0xFFB23AD8.toInt(); c.drawCircle(w * 0.635f, h * 0.048f, h * 0.03f, p)
        p.color = 0xFFE9A6FF.toInt(); c.drawCircle(w * 0.635f, h * 0.048f, h * 0.017f, p)
        label(c, app.chips.toString(), w * 0.77f, h * 0.064f, h * 0.045f, Color.WHITE, Paint.Align.RIGHT)
    }

    private fun gem(c: Canvas, cx: Float, cy: Float, r: Float) {
        p.shader = null; p.style = Paint.Style.FILL
        path.reset()
        path.moveTo(cx, cy - r); path.lineTo(cx + r * 0.9f, cy - r * 0.35f); path.lineTo(cx + r * 0.9f, cy + r * 0.35f)
        path.lineTo(cx, cy + r); path.lineTo(cx - r * 0.9f, cy + r * 0.35f); path.lineTo(cx - r * 0.9f, cy - r * 0.35f)
        path.close()
        p.color = 0xFF2FD14A.toInt(); c.drawPath(path, p)
        p.color = 0xFF8CF29A.toInt()
        path.reset(); path.moveTo(cx, cy - r); path.lineTo(cx + r * 0.9f, cy - r * 0.35f); path.lineTo(cx, cy); path.lineTo(cx - r * 0.9f, cy - r * 0.35f); path.close()
        c.drawPath(path, p)
    }

    private fun drawSidebar(c: Canvas, w: Float, h: Float, sbW: Float) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = 0xFF202B45.toInt()
        c.drawRect(0f, 0f, sbW, h, p)
        val names = arrayOf("Loja", "Personalizar", "Play", "Social", "Config.")
        val sel = if (panel == 0) 2 else when (panel) { 1 -> 0; 2 -> 1; 3 -> 3; 4 -> 4; else -> 2 }
        val ih = h / 5f
        for (i in 0 until 5) {
            val top = i * ih
            if (i == sel) { p.color = 0xFF2C6BD6.toInt(); c.drawRect(0f, top, sbW, top + ih, p) }
            p.color = 0xFF121A2E.toInt(); c.drawRect(0f, top + ih - 2f, sbW, top + ih, p)
            drawIcon(c, i, sbW / 2, top + ih * 0.38f, ih * 0.2f)
            label(c, names[i], sbW / 2, top + ih * 0.85f, h * 0.036f, Color.WHITE, Paint.Align.CENTER)
        }
    }

    private fun drawIcon(c: Canvas, i: Int, cx: Float, cy: Float, r: Float) {
        p.shader = null; p.color = Color.WHITE; p.style = Paint.Style.FILL
        when (i) {
            0 -> { // carrinho
                p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.22f; p.strokeCap = Paint.Cap.ROUND
                path.reset(); path.moveTo(cx - r, cy - r * 0.8f); path.lineTo(cx - r * 0.55f, cy - r * 0.8f)
                path.lineTo(cx - r * 0.2f, cy + r * 0.4f); path.lineTo(cx + r * 0.8f, cy + r * 0.4f)
                path.lineTo(cx + r, cy - r * 0.4f); path.lineTo(cx - r * 0.5f, cy - r * 0.4f)
                c.drawPath(path, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx - r * 0.1f, cy + r * 0.85f, r * 0.2f, p)
                c.drawCircle(cx + r * 0.65f, cy + r * 0.85f, r * 0.2f, p)
            }
            1 -> { // carinha
                c.drawCircle(cx, cy, r, p)
                p.color = 0xFF202B45.toInt()
                c.drawCircle(cx - r * 0.35f, cy - r * 0.1f, r * 0.14f, p)
                c.drawCircle(cx + r * 0.35f, cy - r * 0.1f, r * 0.14f, p)
                rf.set(cx - r * 0.3f, cy + r * 0.25f, cx + r * 0.3f, cy + r * 0.5f)
                c.drawRoundRect(rf, r * 0.1f, r * 0.1f, p)
            }
            2 -> { // play
                path.reset(); path.moveTo(cx - r * 0.7f, cy - r); path.lineTo(cx + r * 0.9f, cy); path.lineTo(cx - r * 0.7f, cy + r); path.close()
                c.drawPath(path, p)
            }
            3 -> { // balão
                rf.set(cx - r, cy - r * 0.8f, cx + r, cy + r * 0.6f)
                c.drawRoundRect(rf, r * 0.4f, r * 0.4f, p)
                path.reset(); path.moveTo(cx - r * 0.4f, cy + r * 0.5f); path.lineTo(cx - r * 0.6f, cy + r * 1.1f); path.lineTo(cx, cy + r * 0.5f); path.close()
                c.drawPath(path, p)
            }
            else -> { // engrenagem
                for (k in 0 until 8) {
                    c.save(); c.rotate(k * 45f, cx, cy)
                    rf.set(cx - r * 0.18f, cy - r * 1.0f, cx + r * 0.18f, cy - r * 0.6f)
                    c.drawRect(rf, p); c.restore()
                }
                c.drawCircle(cx, cy, r * 0.75f, p)
                p.color = 0xFF202B45.toInt(); c.drawCircle(cx, cy, r * 0.3f, p)
            }
        }
        p.strokeCap = Paint.Cap.BUTT; p.style = Paint.Style.FILL
    }

    private fun drawPlay(c: Canvas, w: Float, h: Float) {
        rPlay.set(w * 0.735f, h * 0.76f, w * 0.975f, h * 0.94f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, rPlay.top, 0f, rPlay.bottom, 0xFFFFD43B.toInt(), 0xFFF0A100.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(rPlay, h * 0.012f, h * 0.012f, p)
        p.shader = null
        c.save(); c.clipRect(rPlay)
        p.color = Color.argb(60, 255, 255, 255)
        for (k in 0 until 2) {
            val x0 = rPlay.left + rPlay.width() * (0.15f + k * 0.5f)
            path.reset(); path.moveTo(x0, rPlay.bottom); path.lineTo(x0 + rPlay.width() * 0.2f, rPlay.bottom)
            path.lineTo(x0 + rPlay.width() * 0.5f, rPlay.top); path.lineTo(x0 + rPlay.width() * 0.3f, rPlay.top); path.close()
            c.drawPath(path, p)
        }
        c.restore()
        p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.008f; p.color = 0xFF8A4B00.toInt()
        c.drawRoundRect(rPlay, h * 0.012f, h * 0.012f, p)
        p.style = Paint.Style.FILL
        outlined(c, "Play", rPlay.centerX(), rPlay.centerY() + h * 0.04f, h * 0.115f, Color.WHITE, 0xFF4A2A00.toInt())
    }

    private fun drawWheelButton(c: Canvas, w: Float, h: Float) {
        rWheelBtn.set(w * 0.855f, h * 0.17f, w * 0.975f, h * 0.38f)
        roundRect(c, rWheelBtn, h * 0.03f, 0xFF7A3FE0.toInt())
        // mini roleta
        val cx = rWheelBtn.centerX(); val cy = rWheelBtn.top + h * 0.085f; val r = h * 0.06f
        val cols = intArrayOf(0xFF35C238.toInt(), 0xFFB23AD8.toInt(), 0xFF2F8BE6.toInt(), 0xFFF08A1C.toInt())
        rf.set(cx - r, cy - r, cx + r, cy + r)
        p.style = Paint.Style.FILL
        for (k in 0 until 4) { p.color = cols[k]; c.drawArc(rf, k * 90f, 90f, true, p) }
        p.color = Color.WHITE; c.drawCircle(cx, cy, r * 0.22f, p)
        label(c, "Roleta", cx, rWheelBtn.bottom - h * 0.06f, h * 0.036f, Color.WHITE, Paint.Align.CENTER)
        label(c, "diária", cx, rWheelBtn.bottom - h * 0.022f, h * 0.036f, Color.WHITE, Paint.Align.CENTER)
        if (app.canSpin()) {
            p.color = 0xFFE53935.toInt(); c.drawCircle(rWheelBtn.right - h * 0.012f, rWheelBtn.top + h * 0.012f, h * 0.027f, p)
            label(c, "!", rWheelBtn.right - h * 0.012f, rWheelBtn.top + h * 0.024f, h * 0.036f, Color.WHITE, Paint.Align.CENTER)
        }
    }

    private fun closeButton(c: Canvas, cx: Float, cy: Float, r: Float) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = 0xFFE53935.toInt()
        c.drawCircle(cx, cy, r, p)
        label(c, "X", cx, cy + r * 0.35f, r * 1.0f, Color.WHITE, Paint.Align.CENTER)
        rClose.set(cx - r * 1.4f, cy - r * 1.4f, cx + r * 1.4f, cy + r * 1.4f)
    }

    private fun simplePanel(c: Canvas, w: Float, h: Float, title: String, msg: String) {
        p.shader = null; p.style = Paint.Style.FILL; p.color = Color.argb(130, 0, 0, 0)
        c.drawRect(w * 0.155f, h * 0.095f, w, h, p)
        rf.set(w * 0.25f, h * 0.2f, w * 0.85f, h * 0.8f)
        roundRect(c, rf, h * 0.04f, 0xFF223A6B.toInt())
        label(c, title, rf.centerX(), h * 0.33f, h * 0.075f, Color.WHITE, Paint.Align.CENTER)
        label(c, msg, rf.centerX(), h * 0.55f, h * 0.06f, 0xFFBFD4FF.toInt(), Paint.Align.CENTER)
        closeButton(c, rf.right - h * 0.03f, rf.top + h * 0.03f, h * 0.035f)
    }

    private fun drawSettings(c: Canvas, w: Float, h: Float) {
        simplePanel(c, w, h, "Configurações", "")
        rNameBtn.set(w * 0.4f, h * 0.45f, w * 0.7f, h * 0.58f)
        roundRect(c, rNameBtn, h * 0.03f, 0xFF2C6BD6.toInt())
        label(c, "Mudar nome", rNameBtn.centerX(), rNameBtn.centerY() + h * 0.02f, h * 0.05f, Color.WHITE, Paint.Align.CENTER)
    }

    private fun drawCustomize(c: Canvas, w: Float, h: Float) {
        rf.set(w * 0.17f, h * 0.57f, w * 0.995f, h * 0.99f)
        roundRect(c, rf, h * 0.03f, Color.argb(235, 20, 40, 90))
        label(c, "Personalizar", w * 0.2f, h * 0.66f, h * 0.05f, Color.WHITE, Paint.Align.LEFT)
        closeButton(c, w * 0.965f, h * 0.635f, h * 0.035f)
        val cw = w * 0.2f
        for (i in 0 until 2) {
            val r = if (i == 0) rCard0 else rCard1
            r.set(w * 0.2f + i * (cw + w * 0.03f), h * 0.7f, w * 0.2f + i * (cw + w * 0.03f) + cw, h * 0.96f)
            roundRect(c, r, h * 0.025f, if (i == 0) 0xFFB59A78.toInt() else 0xFFF08A1C.toInt())
            if (app.skin == i) {
                p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.01f; p.color = Color.WHITE
                c.drawRoundRect(r, h * 0.025f, h * 0.025f, p); p.style = Paint.Style.FILL
            }
            label(c, AppState.SKIN_RARITY[i], r.centerX(), r.top + h * 0.06f, h * 0.045f, Color.WHITE, Paint.Align.CENTER)
            label(c, AppState.SKIN_NAMES[i], r.centerX(), r.top + h * 0.13f, h * 0.055f, Color.WHITE, Paint.Align.CENTER)
            label(c, if (app.skin == i) "Equipado ✓" else "Equipar", r.centerX(), r.bottom - h * 0.04f, h * 0.04f,
                if (app.skin == i) 0xFFFFFFFF.toInt() else 0xFF3A2A10.toInt(), Paint.Align.CENTER)
        }
    }

    private fun drawWheel(c: Canvas, w: Float, h: Float) {
        p.shader = LinearGradient(0f, 0f, 0f, h, 0xFF3E8EEA.toInt(), 0xFF123A86.toInt(), Shader.TileMode.CLAMP)
        p.style = Paint.Style.FILL
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        // título
        rf.set(w * 0.32f, h * 0.025f, w * 0.68f, h * 0.15f)
        roundRect(c, rf, h * 0.035f, Color.WHITE)
        label(c, "RODADA SORTUDA", w / 2, h * 0.105f, h * 0.06f, 0xFF1B2A4A.toInt(), Paint.Align.CENTER)
        rf.set(w * 0.4f, h * 0.15f, w * 0.6f, h * 0.2f)
        roundRect(c, rf, h * 0.02f, 0xFFCDBFA8.toInt())
        label(c, "Comum ou Melhor", w / 2, h * 0.187f, h * 0.034f, 0xFF4A3F2E.toInt(), Paint.Align.CENTER)
        closeButton(c, w * 0.955f, h * 0.075f, h * 0.04f)

        val cx = w / 2; val cy = h * 1.0f; val R = h * 0.70f
        c.save(); c.rotate(wheelAngle, cx, cy)
        rf.set(cx - R, cy - R, cx + R, cy + R)
        for (i in prizes.indices) {
            c.save(); c.rotate(i * 45f, cx, cy)
            val pr = prizes[i]
            p.style = Paint.Style.FILL; p.color = pr.color
            c.drawArc(rf, -90f - 22.5f, 45f, true, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.006f; p.color = Color.argb(120, 255, 255, 255)
            c.drawArc(rf, -90f - 22.5f, 45f, true, p)
            p.style = Paint.Style.FILL
            label(c, pr.title, cx, cy - R * 0.9f, h * 0.04f, Color.WHITE, Paint.Align.CENTER)
            prizeIcon(c, pr.icon, cx, cy - R * 0.72f, h * 0.075f, pr.color)
            val big = pr.value.length <= 2
            label(c, pr.value, cx, cy - R * (if (big) 0.52f else 0.54f), if (big) h * 0.07f else h * 0.04f, Color.WHITE, Paint.Align.CENTER)
            c.restore()
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.04f; p.color = 0xFF2D6FD1.toInt()
        c.drawCircle(cx, cy, R + h * 0.018f, p)
        p.style = Paint.Style.FILL
        for (i in 0 until 8) {
            c.save(); c.rotate(i * 45f + 22.5f, cx, cy)
            p.color = 0xFFFFF3B0.toInt(); c.drawCircle(cx, cy - R - h * 0.018f, h * 0.014f, p)
            c.restore()
        }
        c.restore()

        // ponteiro
        p.color = 0xFFE53935.toInt()
        c.drawCircle(cx, cy - R - h * 0.05f, h * 0.04f, p)
        path.reset(); path.moveTo(cx - h * 0.034f, cy - R - h * 0.035f); path.lineTo(cx + h * 0.034f, cy - R - h * 0.035f)
        path.lineTo(cx, cy - R + h * 0.015f); path.close(); c.drawPath(path, p)
        p.color = Color.WHITE; c.drawCircle(cx, cy - R - h * 0.05f, h * 0.014f, p)

        // botão central
        hubX = cx; hubY = cy; hubR = h * 0.15f
        val can = app.canSpin() && !spinning
        p.color = if (can) 0xFFFFC62D.toInt() else 0xFF8896B3.toInt()
        c.drawCircle(hubX, hubY, hubR, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.008f; p.color = Color.WHITE
        c.drawCircle(hubX, hubY, hubR, p); p.style = Paint.Style.FILL
        if (can) outlined(c, "GIRAR", cx, h * 0.935f, h * 0.06f, Color.WHITE, 0xFF4A2A00.toInt())
        else if (spinning) label(c, "...", cx, h * 0.94f, h * 0.06f, Color.WHITE, Paint.Align.CENTER)
        else label(c, "Volte amanhã", cx, h * 0.94f, h * 0.04f, Color.WHITE, Paint.Align.CENTER)
    }

    private fun prizeIcon(c: Canvas, kind: Int, cx: Float, cy: Float, s: Float, base: Int) {
        p.style = Paint.Style.FILL
        when (kind) {
            0 -> for (k in 0 until 3) {
                rf.set(cx - s * 0.7f + k * s * 0.15f, cy + s * 0.25f - k * s * 0.28f, cx + s * 0.1f + k * s * 0.15f, cy + s * 0.55f - k * s * 0.28f)
                p.color = 0xFF7A1F99.toInt(); c.drawOval(rf, p)
                rf.offset(0f, -s * 0.06f); p.color = 0xFFE9A6FF.toInt(); c.drawOval(rf, p)
            }
            1 -> { gem(c, cx - s * 0.35f, cy + s * 0.1f, s * 0.38f); gem(c, cx + s * 0.35f, cy, s * 0.4f); gem(c, cx, cy + s * 0.3f, s * 0.42f) }
            else -> {
                p.color = Color.argb(200, 30, 30, 50)
                c.drawCircle(cx, cy - s * 0.25f, s * 0.28f, p)
                rf.set(cx - s * 0.4f, cy, cx + s * 0.4f, cy + s * 0.75f)
                c.drawRoundRect(rf, s * 0.2f, s * 0.2f, p)
            }
        }
    }
}
