package com.stumble.run

import android.content.Context
import java.util.Calendar

/** Dados do jogador (salvos no celular) e qual tela está aberta. */
class AppState(ctx: Context) {
    private val sp = ctx.getSharedPreferences("stumble", Context.MODE_PRIVATE)

    @Volatile var mode = 0            // 0 = menu, 1 = corrida
    @Volatile var name: String = sp.getString("name", "player") ?: "player"
    @Volatile var gems = sp.getInt("gems", 0)
    @Volatile var chips = sp.getInt("chips", 0)
    @Volatile var skin = sp.getInt("skin", 1)   // 1 = Ninja Ryu
    var lastSpin = sp.getInt("lastSpin", 0)

    companion object {
        val SKIN_FILES = arrayOf("skin1_model.glb", "skin110_model.glb")
        val SKIN_NAMES = arrayOf("Mr Stumble", "Ninja Ryu")
        val SKIN_RARITY = arrayOf("Comum", "Épico")
    }

    private fun today(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    fun canSpin(): Boolean = lastSpin != today()
    fun markSpun() { lastSpin = today() }

    fun save() {
        sp.edit().putString("name", name).putInt("gems", gems).putInt("chips", chips)
            .putInt("skin", skin).putInt("lastSpin", lastSpin).apply()
    }
}
