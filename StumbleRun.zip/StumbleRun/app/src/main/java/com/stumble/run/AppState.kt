package com.stumble.run

import android.content.Context
import java.util.Calendar

/** Dados do jogador (salvos no celular) e qual tela está aberta. */
class AppState(ctx: Context) {
    private val sp = ctx.getSharedPreferences("stumble", Context.MODE_PRIVATE)

    @Volatile var mode = 0            // 0 = menu, 1 = corrida
    @Volatile var name: String = sp.getString("name", "player") ?: "player"
    @Volatile var gems = sp.getInt("gems", 0)
    @Volatile var chips = sp.getInt("chips", 0)
    @Volatile var crowns = sp.getInt("crowns", 0)
    @Volatile var owned = sp.getInt("owned", 1) or 1      // bit 0 = Mr Stumble (grátis)
    @Volatile var skin: Int = sp.getInt("skin", 0).let { if (it in 0..1 && ((owned shr it) and 1) == 1) it else 0 }
    @Volatile var btnScale = sp.getFloat("btnScale", 1f)
    var lastSpin = sp.getInt("lastSpin", 0)

    companion object {
        val SKIN_FILES = arrayOf("skin1_model.glb", "skin110_model.glb")
        val SKIN_NAMES = arrayOf("Mr Stumble", "Ninja Ryu")
        val SKIN_RARITY = arrayOf("Comum", "Épico")
        val SKIN_PRICE = intArrayOf(0, 100)
    }

    fun has(i: Int): Boolean = ((owned shr i) and 1) == 1
    fun unlock(i: Int) { owned = owned or (1 shl i) }

    fun level(): String = when {
        crowns >= 30 -> "Diamante"
        crowns >= 15 -> "Ouro"
        crowns >= 5 -> "Prata"
        else -> "Bronze"
    }

    private fun today(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    fun canSpin(): Boolean = lastSpin != today()
    fun markSpun() { lastSpin = today() }

    fun save() {
        sp.edit().putString("name", name).putInt("gems", gems).putInt("chips", chips)
            .putInt("crowns", crowns).putInt("owned", owned).putInt("skin", skin)
            .putFloat("btnScale", btnScale).putInt("lastSpin", lastSpin).apply()
    }
}
