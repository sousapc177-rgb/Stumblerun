package com.stumble.run

import android.content.Context
import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

class GameRenderer(
    private val ctx: Context,
    private val game: Game,
    private val app: AppState
) : GLSurfaceView.Renderer {

    private val FS = """
        precision mediump float;
        varying vec3 vN; varying vec2 vUV; varying vec3 vW;
        uniform sampler2D uTex; uniform vec4 uColor; uniform float uUseTex; uniform float uChecker;
        uniform vec3 uSkin;
        void main() {
            vec3 n = normalize(vN);
            float l = max(dot(n, normalize(vec3(0.4, 1.0, 0.6))), 0.0);
            vec3 base = uColor.rgb;
            if (uUseTex > 0.5) {
                vec4 t = texture2D(uTex, vUV);
                base = mix(uSkin, t.rgb, t.a) * uColor.rgb;
            }
            if (uChecker > 0.5) {
                float c = mod(floor(vW.x / 2.0) + floor(vW.z / 2.0), 2.0);
                base *= 0.84 + 0.16 * c;
            }
            gl_FragColor = vec4(base * (0.55 + 0.55 * l), 1.0);
        }
    """
    private val VS_SKIN = """
        uniform mat4 uVP; uniform mat4 uModel; uniform mat4 uBones[24];
        attribute vec3 aPos; attribute vec3 aNrm; attribute vec2 aUV; attribute vec4 aJ; attribute vec4 aW;
        varying vec3 vN; varying vec2 vUV; varying vec3 vW;
        void main() {
            mat4 s = uBones[int(aJ.x + 0.5)] * aW.x + uBones[int(aJ.y + 0.5)] * aW.y
                   + uBones[int(aJ.z + 0.5)] * aW.z + uBones[int(aJ.w + 0.5)] * aW.w;
            vec4 p = uModel * (s * vec4(aPos, 1.0));
            vN = (uModel * (s * vec4(aNrm, 0.0))).xyz;
            vUV = aUV; vW = p.xyz;
            gl_Position = uVP * p;
        }
    """
    private val VS_STATIC = """
        uniform mat4 uVP; uniform mat4 uModel; uniform vec3 uScale;
        attribute vec3 aPos; attribute vec3 aNrm;
        varying vec3 vN; varying vec2 vUV; varying vec3 vW;
        void main() {
            vec4 p = uModel * vec4(aPos * uScale, 1.0);
            vN = (uModel * vec4(aNrm, 0.0)).xyz;
            vUV = vec2(0.0); vW = p.xyz;
            gl_Position = uVP * p;
        }
    """
    private val VS_BG = """
        attribute vec2 aP; varying vec2 vP;
        void main() { vP = aP * 0.5 + 0.5; gl_Position = vec4(aP, 0.0, 1.0); }
    """
    private val FS_BG = """
        precision mediump float;
        varying vec2 vP;
        void main() {
            vec2 d = (vP - vec2(0.5, 0.45)) * vec2(1.0, 1.25);
            float r = length(d);
            vec3 c = mix(vec3(0.60, 0.84, 1.0), vec3(0.06, 0.42, 0.96), smoothstep(0.0, 0.7, r));
            vec2 e = (vP - vec2(0.5, 0.27)) / vec2(0.20, 0.05);
            float s = 1.0 - smoothstep(0.6, 1.0, length(e));
            c = mix(c, vec3(0.10, 0.25, 0.50), s * 0.5);
            gl_FragColor = vec4(c, 1.0);
        }
    """

    private class SkinData(val model: GlbModel, val texId: Int) {
        val extra: Array<FloatArray?> = arrayOfNulls(model.nodeCount)
        val pool = Array(model.nodeCount) { FloatArray(4) }
        val uL = model.nodeIndex["UpperLeg.L"]!!; val uR = model.nodeIndex["UpperLeg.R"]!!
        val lL = model.nodeIndex["LowerLeg.L"]!!; val lR = model.nodeIndex["LowerLeg.R"]!!
        val aL = model.nodeIndex["UpperArm.L"]!!; val aR = model.nodeIndex["UpperArm.R"]!!
        val sp = model.nodeIndex["Spine"]!!
    }

    private val skins = ArrayList<SkinData>()
    private var pSkin = 0
    private var pStat = 0
    private var pBg = 0
    private lateinit var cube: FloatBuffer
    private lateinit var quad: FloatBuffer
    private val proj = FloatArray(16); private val view = FloatArray(16)
    private val vp = FloatArray(16); private val m = FloatArray(16)
    private val bones = FloatArray(24 * 16)
    private var last = 0L
    private var camX = 0f; private var camZ = 4f
    private var aspect = 1.8f
    private var lobbyT = 0f

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.42f, 0.72f, 1f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        pSkin = program(VS_SKIN, FS); pStat = program(VS_STATIC, FS); pBg = program(VS_BG, FS_BG)
        skins.clear()
        for (f in AppState.SKIN_FILES) {
            val model = GlbModel(ctx, f)
            skins.add(SkinData(model, uploadTexture(model.texture)))
        }
        buildCube()
        val qb = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        qb.put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); qb.position(0); quad = qb
        last = System.nanoTime()
    }

    private fun uploadTexture(bmp: Bitmap): Int {
        val t = IntArray(1); GLES20.glGenTextures(1, t, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        return t[0]
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h); aspect = w.toFloat() / h
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = (now - last) / 1e9f; last = now
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        if (app.mode == 1) {
            game.update(dt)
            drawGame(dt)
        } else {
            drawLobby(dt)
        }
    }

    // ---------- menu ----------
    private fun drawLobby(dt: Float) {
        lobbyT += dt
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glUseProgram(pBg)
        val aP = GLES20.glGetAttribLocation(pBg, "aP")
        quad.position(0)
        GLES20.glVertexAttribPointer(aP, 2, GLES20.GL_FLOAT, false, 8, quad)
        GLES20.glEnableVertexAttribArray(aP)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)

        Matrix.perspectiveM(proj, 0, 40f, aspect, 0.1f, 50f)
        Matrix.setLookAtM(view, 0, 0f, 1.15f, 4.3f, 0f, 0.95f, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        val sd = skins[app.skin.coerceIn(0, skins.size - 1)]
        java.util.Arrays.fill(sd.extra, null)
        val w = sin(lobbyT * 1.6f) * 0.06f
        qx(sd, sd.aL, w); qx(sd, sd.aR, -w)
        val yaw = sin(lobbyT * 0.7f) * 25f
        drawSkinned(sd, 0.12f, 0f, 0f, yaw, floatArrayOf(1f, 1f, 1f))
    }

    // ---------- jogo ----------
    private fun drawGame(dt: Float) {
        val p = game.player
        val k = min(1f, dt * 5f)
        camX += (p.x - camX) * k; camZ += (p.z - camZ) * min(1f, dt * 8f)
        Matrix.perspectiveM(proj, 0, 60f, aspect, 0.1f, 300f)
        val yw = game.camYaw
        Matrix.setLookAtM(view, 0, camX * 0.5f + sin(yw) * 8f, 4.6f, camZ + cos(yw) * 8f,
            camX * 0.7f - sin(yw) * 4f, 1.3f, camZ - cos(yw) * 4f, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        drawWorld()
        for (r in game.racers) {
            val sd = skins[r.skin.coerceIn(0, skins.size - 1)]
            pose(sd, r)
            val bob = abs(sin(r.phase)) * 0.08f * min(1f, hypot(r.vx, r.vz) / 7f)
            drawSkinned(sd, r.x, r.y + bob, r.z, Math.toDegrees(r.yaw.toDouble()).toFloat(), r.color)
        }
    }

    private fun drawWorld() {
        GLES20.glUseProgram(pStat)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pStat, "uVP"), 1, false, vp, 0)
        for (f in game.floors) {
            val len = f[0] - f[1]
            box(0f, -0.5f, (f[0] + f[1]) / 2, Game.HALF * 2, 1f, len, 0f, 0.96f, 0.55f, 0.82f, true)
            box(-Game.HALF - 0.2f, 0.3f, (f[0] + f[1]) / 2, 0.4f, 0.8f, len, 0f, 0.35f, 0.3f, 0.8f, false)
            box(Game.HALF + 0.2f, 0.3f, (f[0] + f[1]) / 2, 0.4f, 0.8f, len, 0f, 0.35f, 0.3f, 0.8f, false)
        }
        box(0f, -25f, -130f, 400f, 1f, 600f, 0f, 0.35f, 0.15f, 0.55f, false)
        box(0f, 0.02f, -Game.FIN, Game.HALF * 2, 0.05f, 2f, 0f, 1f, 1f, 1f, true)
        box(-Game.HALF, 3f, -Game.FIN, 0.6f, 6f, 0.6f, 0f, 1f, 0.8f, 0.1f, false)
        box(Game.HALF, 3f, -Game.FIN, 0.6f, 6f, 0.6f, 0f, 1f, 0.8f, 0.1f, false)
        box(0f, 6f, -Game.FIN, Game.HALF * 2 + 0.6f, 0.8f, 0.6f, 0f, 1f, 0.3f, 0.3f, false)
        for (s in game.spinners) {
            val ang = Math.toDegrees((game.t * s.speed).toDouble()).toFloat()
            box(s.x, 0.5f, s.z, 2f * s.len, 0.5f, 0.4f, -ang, 1f, 0.85f, 0.1f, false)
            box(s.x, 0.6f, s.z, 0.7f, 1.2f, 0.7f, 0f, 0.9f, 0.3f, 0.2f, false)
        }
        for (s in game.sliders) {
            val sx = sin(game.t * s.speed + s.ph) * s.range
            box(sx, 0.8f, s.z, s.w, 1.6f, 1f, 0f, 1f, 0.45f, 0.15f, false)
        }
    }

    private fun box(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, rotY: Float,
                    r: Float, g: Float, b: Float, checker: Boolean) {
        Matrix.setIdentityM(m, 0)
        Matrix.translateM(m, 0, x, y, z)
        Matrix.rotateM(m, 0, rotY, 0f, 1f, 0f)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pStat, "uModel"), 1, false, m, 0)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(pStat, "uScale"), sx, sy, sz)
        GLES20.glUniform4f(GLES20.glGetUniformLocation(pStat, "uColor"), r, g, b, 1f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pStat, "uUseTex"), 0f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pStat, "uChecker"), if (checker) 1f else 0f)
        val aP = GLES20.glGetAttribLocation(pStat, "aPos"); val aN = GLES20.glGetAttribLocation(pStat, "aNrm")
        cube.position(0); GLES20.glVertexAttribPointer(aP, 3, GLES20.GL_FLOAT, false, 24, cube)
        GLES20.glEnableVertexAttribArray(aP)
        cube.position(3); GLES20.glVertexAttribPointer(aN, 3, GLES20.GL_FLOAT, false, 24, cube)
        GLES20.glEnableVertexAttribArray(aN)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }

    private fun buildCube() {
        val faces = arrayOf(
            floatArrayOf(0f, 0f, 1f, -1f, -1f, 1f, 1f, -1f, 1f, 1f, 1f, 1f, -1f, 1f, 1f),
            floatArrayOf(0f, 0f, -1f, 1f, -1f, -1f, -1f, -1f, -1f, -1f, 1f, -1f, 1f, 1f, -1f),
            floatArrayOf(1f, 0f, 0f, 1f, -1f, 1f, 1f, -1f, -1f, 1f, 1f, -1f, 1f, 1f, 1f),
            floatArrayOf(-1f, 0f, 0f, -1f, -1f, -1f, -1f, -1f, 1f, -1f, 1f, 1f, -1f, 1f, -1f),
            floatArrayOf(0f, 1f, 0f, -1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, -1f, -1f, 1f, -1f),
            floatArrayOf(0f, -1f, 0f, -1f, -1f, -1f, 1f, -1f, -1f, 1f, -1f, 1f, -1f, -1f, 1f)
        )
        val fb = ByteBuffer.allocateDirect(36 * 6 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (f in faces) {
            for (idx in intArrayOf(0, 1, 2, 0, 2, 3)) {
                fb.put(f[3 + idx * 3] * 0.5f); fb.put(f[4 + idx * 3] * 0.5f); fb.put(f[5 + idx * 3] * 0.5f)
                fb.put(f[0]); fb.put(f[1]); fb.put(f[2])
            }
        }
        fb.position(0); cube = fb
    }

    // ---------- personagens ----------
    private fun qx(sd: SkinData, i: Int, a: Float) {
        val q = sd.pool[i]; q[0] = sin(a / 2); q[1] = 0f; q[2] = 0f; q[3] = cos(a / 2); sd.extra[i] = q
    }

    private fun pose(sd: SkinData, r: Racer) {
        java.util.Arrays.fill(sd.extra, null)
        val speed = hypot(r.vx, r.vz)
        val amp = min(1f, speed / 7f)
        val s = sin(r.phase)
        if (r.finished) {
            val w = sin(game.t * 8f) * 0.3f
            qx(sd, sd.aL, 2.8f + w); qx(sd, sd.aR, 2.8f - w)
        } else if (r.stun > 0f) {
            val f = sin(game.t * 22f) * 1.1f
            qx(sd, sd.aL, 1.2f + f); qx(sd, sd.aR, 1.2f - f); qx(sd, sd.sp, -0.35f)
            qx(sd, sd.uL, 0.5f); qx(sd, sd.uR, -0.4f)
        } else if (!r.onGround) {
            qx(sd, sd.aL, 2.2f); qx(sd, sd.aR, 2.2f)
            qx(sd, sd.uL, 0.6f); qx(sd, sd.uR, -0.5f); qx(sd, sd.lL, 0.7f)
        } else if (amp > 0.05f) {
            qx(sd, sd.uL, 0.9f * amp * s); qx(sd, sd.uR, -0.9f * amp * s)
            qx(sd, sd.lL, 0.8f * amp * max(0f, s)); qx(sd, sd.lR, 0.8f * amp * max(0f, -s))
            qx(sd, sd.aL, 0.8f * amp * s); qx(sd, sd.aR, -0.8f * amp * s)
            qx(sd, sd.sp, 0.18f * amp)
        } else {
            val w = sin(game.t * 2f) * 0.08f
            qx(sd, sd.aL, w); qx(sd, sd.aR, -w)
        }
    }

    private fun drawSkinned(sd: SkinData, x: Float, y: Float, z: Float, yawDeg: Float, color: FloatArray) {
        val model = sd.model
        GLES20.glUseProgram(pSkin)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pSkin, "uVP"), 1, false, vp, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, sd.texId)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(pSkin, "uTex"), 0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pSkin, "uUseTex"), 1f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pSkin, "uChecker"), 0f)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(pSkin, "uSkin"),
            model.skinColor[0], model.skinColor[1], model.skinColor[2])
        GLES20.glUniform4f(GLES20.glGetUniformLocation(pSkin, "uColor"), color[0], color[1], color[2], 1f)

        model.computeBones(sd.extra, bones)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pSkin, "uBones"), model.jointCount, false, bones, 0)
        Matrix.setIdentityM(m, 0)
        Matrix.translateM(m, 0, x, y, z)
        Matrix.rotateM(m, 0, yawDeg, 0f, 1f, 0f)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pSkin, "uModel"), 1, false, m, 0)

        val aPos = GLES20.glGetAttribLocation(pSkin, "aPos"); val aNrm = GLES20.glGetAttribLocation(pSkin, "aNrm")
        val aUV = GLES20.glGetAttribLocation(pSkin, "aUV"); val aJ = GLES20.glGetAttribLocation(pSkin, "aJ")
        val aW = GLES20.glGetAttribLocation(pSkin, "aW")
        val vb = model.vertexBuf
        vb.position(0); GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 64, vb)
        vb.position(3); GLES20.glVertexAttribPointer(aNrm, 3, GLES20.GL_FLOAT, false, 64, vb)
        vb.position(6); GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 64, vb)
        vb.position(8); GLES20.glVertexAttribPointer(aJ, 4, GLES20.GL_FLOAT, false, 64, vb)
        vb.position(12); GLES20.glVertexAttribPointer(aW, 4, GLES20.GL_FLOAT, false, 64, vb)
        for (a in intArrayOf(aPos, aNrm, aUV, aJ, aW)) GLES20.glEnableVertexAttribArray(a)
        model.indexBuf.position(0)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, model.indexCount, GLES20.GL_UNSIGNED_SHORT, model.indexBuf)
    }

    // ---------- shaders ----------
    private fun program(vs: String, fs: String): Int {
        fun sh(type: Int, src: String): Int {
            val h = GLES20.glCreateShader(type)
            GLES20.glShaderSource(h, src); GLES20.glCompileShader(h)
            val ok = IntArray(1); GLES20.glGetShaderiv(h, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw RuntimeException("Shader: " + GLES20.glGetShaderInfoLog(h))
            return h
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, sh(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, sh(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        return p
    }
}
