package com.stumble.run

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

class GameRenderer(private val ctx: Context, private val game: Game) : GLSurfaceView.Renderer {
    private val FS = """
        precision mediump float;
        varying vec3 vN; varying vec2 vUV; varying vec3 vW;
        uniform sampler2D uTex; uniform vec4 uColor; uniform float uUseTex; uniform float uChecker;
        void main() {
            vec3 n = normalize(vN);
            float l = max(dot(n, normalize(vec3(0.4, 1.0, 0.6))), 0.0);
            vec3 base = uColor.rgb;
            if (uUseTex > 0.5) base = texture2D(uTex, vUV).rgb * uColor.rgb;
            if (uChecker > 0.5) {
                float c = mod(floor(vW.x / 2.0) + floor(vW.z / 2.0), 2.0);
                base *= 0.84 + 0.16 * c;
            }
            gl_FragColor = vec4(base * (0.55 + 0.55 * l), 1.0);
        }
    """
    private val VS_SKIN = """
        uniform mat4 uVP; uniform mat4 uModel; uniform mat4 uBones[17];
        attribute vec3 aPos; attribute vec3 aNrm; attribute vec2 aUV; attribute vec4 aJ; attribute vec4 aW;
        varying vec3 vN; varying vec2 vUV; varying vec3 vW;
        void main() {
            mat4 s = uBones[int(aJ.x + 0.5)] * aW.x + uBones[int(aJ.y + 0.5)] * aW.y
                   + uBones[int(aJ.z + 0.5)] * aW.z + uBones[int(aJ.w + 0.5)] * aW.w;
            vec4 p = uModel * (s * vec4(aPos, 1.0));
            vN = (uModel * (s * vec4(aNrm, 0.0))).xyz;
            vUV = aUV; vW = p.xyz;
            gl_Position = uVP * p;
        }
    """
    private val VS_STATIC = """
        uniform mat4 uVP; uniform mat4 uModel; uniform vec3 uScale;
        attribute vec3 aPos; attribute vec3 aNrm;
        varying vec3 vN; varying vec2 vUV; varying vec3 vW;
        void main() {
            vec4 p = uModel * vec4(aPos * uScale, 1.0);
            vN = (uModel * vec4(aNrm, 0.0)).xyz;
            vUV = vec2(0.0); vW = p.xyz;
            gl_Position = uVP * p;
        }
    """

    private lateinit var model: GlbModel
    private var pSkin = 0
    private var pStat = 0
    private var texId = 0
    private lateinit var cube: FloatBuffer
    private val proj = FloatArray(16); private val view = FloatArray(16)
    private val vp = FloatArray(16); private val m = FloatArray(16); private val m2 = FloatArray(16)
    private val bones = FloatArray(17 * 16)
    private var extra: Array<FloatArray?> = arrayOf()
    private lateinit var pool: Array<FloatArray>
    private var last = 0L
    private var camX = 0f; private var camZ = 4f
    private var aspect = 1.8f

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.42f, 0.72f, 1f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        pSkin = program(VS_SKIN, FS); pStat = program(VS_STATIC, FS)
        model = GlbModel(ctx, "skin1_model.glb")
        extra = arrayOfNulls(model.nodeCount)
        pool = Array(model.nodeCount) { FloatArray(4) }
        val t = IntArray(1); GLES20.glGenTextures(1, t, 0); texId = t[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, model.texture, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        buildCube()
        last = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h); aspect = w.toFloat() / h
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = (now - last) / 1e9f; last = now
        game.update(dt)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val p = game.player
        val k = min(1f, dt * 5f)
        camX += (p.x - camX) * k; camZ += (p.z - camZ) * min(1f, dt * 8f)
        Matrix.perspectiveM(proj, 0, 60f, aspect, 0.1f, 300f)
        Matrix.setLookAtM(view, 0, camX * 0.5f, 4.6f, camZ + 8f, camX * 0.7f, 1.3f, camZ - 4f, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        drawWorld()
        drawRacers()
    }

    // ---------- mundo ----------
    private fun drawWorld() {
        GLES20.glUseProgram(pStat)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pStat, "uVP"), 1, false, vp, 0)
        for (f in game.floors) {
            val len = f[0] - f[1]
            box(0f, -0.5f, (f[0] + f[1]) / 2, Game.HALF * 2, 1f, len, 0f, 0.96f, 0.55f, 0.82f, true)
            box(-Game.HALF - 0.2f, 0.3f, (f[0] + f[1]) / 2, 0.4f, 0.8f, len, 0f, 0.35f, 0.3f, 0.8f, false)
            box(Game.HALF + 0.2f, 0.3f, (f[0] + f[1]) / 2, 0.4f, 0.8f, len, 0f, 0.35f, 0.3f, 0.8f, false)
        }
        box(0f, -25f, -130f, 400f, 1f, 600f, 0f, 0.35f, 0.15f, 0.55f, false) // abismo
        // linha de chegada
        box(0f, 0.02f, -Game.FIN, Game.HALF * 2, 0.05f, 2f, 0f, 1f, 1f, 1f, true)
        box(-Game.HALF, 3f, -Game.FIN, 0.6f, 6f, 0.6f, 0f, 1f, 0.8f, 0.1f, false)
        box(Game.HALF, 3f, -Game.FIN, 0.6f, 6f, 0.6f, 0f, 1f, 0.8f, 0.1f, false)
        box(0f, 6f, -Game.FIN, Game.HALF * 2 + 0.6f, 0.8f, 0.6f, 0f, 1f, 0.3f, 0.3f, false)
        // giradores
        for (s in game.spinners) {
            val ang = Math.toDegrees((game.t * s.speed).toDouble()).toFloat()
            box(s.x, 0.5f, s.z, 2f * s.len, 0.5f, 0.4f, -ang, 1f, 0.85f, 0.1f, false)
            box(s.x, 0.6f, s.z, 0.7f, 1.2f, 0.7f, 0f, 0.9f, 0.3f, 0.2f, false)
        }
        // paredes deslizantes
        for (s in game.sliders) {
            val sx = sin(game.t * s.speed + s.ph) * s.range
            box(sx, 0.8f, s.z, s.w, 1.6f, 1f, 0f, 1f, 0.45f, 0.15f, false)
        }
    }

    private fun box(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, rotY: Float,
                    r: Float, g: Float, b: Float, checker: Boolean) {
        Matrix.setIdentityM(m, 0)
        Matrix.translateM(m, 0, x, y, z)
        Matrix.rotateM(m, 0, rotY, 0f, 1f, 0f)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pStat, "uModel"), 1, false, m, 0)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(pStat, "uScale"), sx, sy, sz)
        GLES20.glUniform4f(GLES20.glGetUniformLocation(pStat, "uColor"), r, g, b, 1f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pStat, "uUseTex"), 0f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pStat, "uChecker"), if (checker) 1f else 0f)
        val aP = GLES20.glGetAttribLocation(pStat, "aPos"); val aN = GLES20.glGetAttribLocation(pStat, "aNrm")
        cube.position(0); GLES20.glVertexAttribPointer(aP, 3, GLES20.GL_FLOAT, false, 24, cube)
        GLES20.glEnableVertexAttribArray(aP)
        cube.position(3); GLES20.glVertexAttribPointer(aN, 3, GLES20.GL_FLOAT, false, 24, cube)
        GLES20.glEnableVertexAttribArray(aN)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }

    private fun buildCube() {
        val faces = arrayOf(
            floatArrayOf(0f, 0f, 1f, -1f, -1f, 1f, 1f, -1f, 1f, 1f, 1f, 1f, -1f, 1f, 1f),
            floatArrayOf(0f, 0f, -1f, 1f, -1f, -1f, -1f, -1f, -1f, -1f, 1f, -1f, 1f, 1f, -1f),
            floatArrayOf(1f, 0f, 0f, 1f, -1f, 1f, 1f, -1f, -1f, 1f, 1f, -1f, 1f, 1f, 1f),
            floatArrayOf(-1f, 0f, 0f, -1f, -1f, -1f, -1f, -1f, 1f, -1f, 1f, 1f, -1f, 1f, -1f),
            floatArrayOf(0f, 1f, 0f, -1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, -1f, -1f, 1f, -1f),
            floatArrayOf(0f, -1f, 0f, -1f, -1f, -1f, 1f, -1f, -1f, 1f, -1f, 1f, -1f, -1f, 1f)
        )
        val fb = ByteBuffer.allocateDirect(36 * 6 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (f in faces) {
            for (idx in intArrayOf(0, 1, 2, 0, 2, 3)) {
                fb.put(f[3 + idx * 3] * 0.5f); fb.put(f[4 + idx * 3] * 0.5f); fb.put(f[5 + idx * 3] * 0.5f)
                fb.put(f[0]); fb.put(f[1]); fb.put(f[2])
            }
        }
        fb.position(0); cube = fb
    }

    // ---------- personagens ----------
    private fun qx(i: Int, a: Float) {
        val q = pool[i]; q[0] = sin(a / 2); q[1] = 0f; q[2] = 0f; q[3] = cos(a / 2); extra[i] = q
    }

    private fun pose(r: Racer) {
        java.util.Arrays.fill(extra, null)
        val n = model.nodeIndex
        val uL = n["UpperLeg.L"]!!; val uR = n["UpperLeg.R"]!!
        val lL = n["LowerLeg.L"]!!; val lR = n["LowerLeg.R"]!!
        val aL = n["UpperArm.L"]!!; val aR = n["UpperArm.R"]!!
        val sp = n["Spine"]!!
        val speed = hypot(r.vx, r.vz)
        val amp = min(1f, speed / 7f)
        val s = sin(r.phase)
        if (r.finished) {
            val w = sin(game.t * 8f) * 0.3f
            qx(aL, 2.8f + w); qx(aR, 2.8f - w)
        } else if (r.stun > 0f) {
            val f = sin(game.t * 22f) * 1.1f
            qx(aL, 1.2f + f); qx(aR, 1.2f - f); qx(sp, -0.35f)
            qx(uL, 0.5f); qx(uR, -0.4f)
        } else if (!r.onGround) {
            qx(aL, 2.2f); qx(aR, 2.2f)
            qx(uL, 0.6f); qx(uR, -0.5f); qx(lL, 0.7f)
        } else if (amp > 0.05f) {
            qx(uL, 0.9f * amp * s); qx(uR, -0.9f * amp * s)
            qx(lL, 0.8f * amp * max(0f, s)); qx(lR, 0.8f * amp * max(0f, -s))
            qx(aL, 0.8f * amp * s); qx(aR, -0.8f * amp * s)
            qx(sp, 0.18f * amp)
        } else {
            val w = sin(game.t * 2f) * 0.08f
            qx(aL, w); qx(aR, -w)
        }
    }

    private fun drawRacers() {
        GLES20.glUseProgram(pSkin)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pSkin, "uVP"), 1, false, vp, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texId)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(pSkin, "uTex"), 0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pSkin, "uUseTex"), 1f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pSkin, "uChecker"), 0f)
        val uBones = GLES20.glGetUniformLocation(pSkin, "uBones")
        val uModel = GLES20.glGetUniformLocation(pSkin, "uModel")
        val uColor = GLES20.glGetUniformLocation(pSkin, "uColor")
        val aPos = GLES20.glGetAttribLocation(pSkin, "aPos"); val aNrm = GLES20.glGetAttribLocation(pSkin, "aNrm")
        val aUV = GLES20.glGetAttribLocation(pSkin, "aUV"); val aJ = GLES20.glGetAttribLocation(pSkin, "aJ")
        val aW = GLES20.glGetAttribLocation(pSkin, "aW")
        val vb = model.vertexBuf
        vb.position(0); GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 64, vb)
        vb.position(3); GLES20.glVertexAttribPointer(aNrm, 3, GLES20.GL_FLOAT, false, 64, vb)
        vb.position(6); GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 64, vb)
        vb.position(8); GLES20.glVertexAttribPointer(aJ, 4, GLES20.GL_FLOAT, false, 64, vb)
        vb.position(12); GLES20.glVertexAttribPointer(aW, 4, GLES20.GL_FLOAT, false, 64, vb)
        for (a in intArrayOf(aPos, aNrm, aUV, aJ, aW)) GLES20.glEnableVertexAttribArray(a)

        for (r in game.racers) {
            pose(r)
            model.computeBones(extra, bones)
            GLES20.glUniformMatrix4fv(uBones, model.jointCount, false, bones, 0)
            val bob = abs(sin(r.phase)) * 0.08f * min(1f, hypot(r.vx, r.vz) / 7f)
            Matrix.setIdentityM(m, 0)
            Matrix.translateM(m, 0, r.x, r.y + bob, r.z)
            Matrix.rotateM(m, 0, Math.toDegrees(r.yaw.toDouble()).toFloat(), 0f, 1f, 0f)
            GLES20.glUniformMatrix4fv(uModel, 1, false, m, 0)
            GLES20.glUniform4f(uColor, r.color[0], r.color[1], r.color[2], 1f)
            model.indexBuf.position(0)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, model.indexCount, GLES20.GL_UNSIGNED_SHORT, model.indexBuf)
        }
    }

    // ---------- shaders ----------
    private fun program(vs: String, fs: String): Int {
        fun sh(type: Int, src: String): Int {
            val h = GLES20.glCreateShader(type)
            GLES20.glShaderSource(h, src); GLES20.glCompileShader(h)
            val ok = IntArray(1); GLES20.glGetShaderiv(h, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw RuntimeException("Shader: " + GLES20.glGetShaderInfoLog(h))
            return h
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, sh(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, sh(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        return p
    }
}
