package com.stumble.run

import kotlin.math.*

class Racer(val isPlayer: Boolean, val skill: Float) {
    var x = 0f; var y = 0f; var z = 0f
    var vx = 0f; var vy = 0f; var vz = 0f
    var yaw = PI.toFloat()
    var onGround = true
    var stun = 0f
    var phase = 0f
    var cool = 0f
    var cpZ = 4f
    var finished = false
    var rank = 0
    var wander = 0f
    val color = floatArrayOf(1f, 1f, 1f)
}

class Game {
    class Hole(val z0: Float, val z1: Float)
    class Spinner(val x: Float, val z: Float, val len: Float, val speed: Float)
    class Slider(val z: Float, val w: Float, val range: Float, val speed: Float, val ph: Float)

    companion object {
        const val FIN = 260f
        const val HALF = 7f
        const val TOTAL = 8
        const val QUALIFY = 4
    }

    val holes = listOf(Hole(-40f, -44.5f), Hole(-85f, -89.5f), Hole(-150f, -154.5f), Hole(-195f, -199.5f))
    val spinners = listOf(
        Spinner(0f, -65f, 6.5f, 1.6f), Spinner(0f, -170f, 6.5f, -1.9f),
        Spinner(-3.5f, -215f, 3.4f, 2.4f), Spinner(3.5f, -215f, 3.4f, -2.4f)
    )
    val sliders = listOf(
        Slider(-105f, 5f, 4f, 1.8f, 0f), Slider(-112f, 5f, 4f, 1.8f, 2f), Slider(-119f, 5f, 4f, 1.8f, 4f),
        Slider(-235f, 5f, 4f, 2.2f, 0f), Slider(-243f, 5f, 4f, 2.2f, 3f)
    )
    private val checkpoints = floatArrayOf(-47f, -100f, -157f, -205f)

    /** pedaços de chão: [zInicio, zFim] (zInicio > zFim) */
    val floors = ArrayList<FloatArray>()

    val racers = ArrayList<Racer>()
    val player: Racer get() = racers[1]

    @Volatile var inX = 0f
    @Volatile var inZ = 0f
    @Volatile var jump = false
    @Volatile var restart = false
    @Volatile var state = 0          // 0 contagem, 1 corrida, 2 fim
    @Volatile var countdown = 3.5f
    @Volatile var overTimer = 0f
    @Volatile var place = 1
    @Volatile var finishTime = 0f
    @Volatile var raceTime = 0f

    var t = 0f
    private var finishCount = 0
    private val rnd = java.util.Random()

    init {
        var z = 12f
        for (h in holes) { floors.add(floatArrayOf(z, h.z0)); z = h.z1 }
        floors.add(floatArrayOf(z, -FIN - 20f))
        reset()
    }

    private fun reset() {
        racers.clear()
        for (i in 0 until TOTAL) {
            val r = Racer(i == 1, 0.75f + rnd.nextFloat() * 0.25f)
            r.x = -4.5f + 3f * (i % 4); r.z = 4.5f - (i / 4) * 2.5f
            r.yaw = PI.toFloat(); r.cpZ = 4f
            if (!r.isPlayer) for (k in 0..2) r.color[k] = 0.65f + rnd.nextFloat() * 0.5f
            racers.add(r)
        }
        state = 0; countdown = 3.5f; overTimer = 0f; finishCount = 0
        raceTime = 0f; finishTime = 0f; place = 1
    }

    private fun groundAt(z: Float): Boolean {
        for (h in holes) if (z < h.z0 - 0.15f && z > h.z1 + 0.15f) return false
        return true
    }

    fun update(dtRaw: Float) {
        if (restart) { restart = false; reset() }
        val dt = min(dtRaw, 0.033f)
        t += dt
        if (state == 0) { countdown -= dt; if (countdown <= 0f) state = 1 }
        if (state >= 1 && !player.finished) raceTime += dt
        for (r in racers) step(r, dt)
        // empurrão entre jogadores
        for (i in 0 until racers.size) for (j in i + 1 until racers.size) {
            val a = racers[i]; val b = racers[j]
            val dx = b.x - a.x; val dz = b.z - a.z
            val d = sqrt(dx * dx + dz * dz)
            if (d < 0.8f && d > 0.001f && abs(a.y - b.y) < 1.2f) {
                val push = (0.8f - d) * 0.5f
                val nx = dx / d; val nz = dz / d
                a.x -= nx * push; a.z -= nz * push; b.x += nx * push; b.z += nz * push
            }
        }
        place = computePlace()
        if (state == 1 && player.finished) { state = 2; overTimer = 0f; finishTime = raceTime }
        if (state == 2) overTimer += dt
    }

    private fun computePlace(): Int {
        val p = player
        if (p.finished) return p.rank
        var c = 1
        for (r in racers) if (r !== p && (r.finished || r.z < p.z)) c++
        return c
    }

    private fun step(r: Racer, dt: Float) {
        var ix = 0f; var iz = 0f; var wantJump = false
        val canMove = !r.finished && (state == 1 || (state == 2 && !r.isPlayer))
        if (canMove) {
            if (r.isPlayer) {
                ix = inX; iz = inZ
                if (jump) { wantJump = true; jump = false }
            } else {
                r.wander += dt
                iz = -(0.85f + 0.15f * r.skill)
                ix = sin(r.wander * 0.7f + r.skill * 10f) * 0.25f - r.x * 0.12f
                var next: Hole? = null
                for (h in holes) if (h.z0 < r.z) { next = h; break }
                if (next != null && r.z - next.z0 < 1.3f + r.skill * 0.5f && r.onGround) wantJump = true
                for (s in spinners) if (r.z > s.z && r.z - s.z < 2.6f && r.onGround && rnd.nextFloat() < 0.15f * r.skill) wantJump = true
            }
        } else if (state == 0 && r.isPlayer) { jump = false }
        r.cool -= dt
        if (r.stun > 0f) r.stun -= dt
        val ctrl = if (r.stun > 0f) 0.12f else 1f
        val maxSp = if (r.isPlayer) 8f else 7.6f * r.skill
        val acc = (if (r.onGround) 32f else 11f) * ctrl
        val tvx = ix * maxSp; val tvz = iz * maxSp
        r.vx += (tvx - r.vx).coerceIn(-acc * dt, acc * dt)
        r.vz += (tvz - r.vz).coerceIn(-acc * dt, acc * dt)
        r.vy -= 26f * dt
        if (wantJump && r.onGround && r.stun <= 0f && r.cool <= 0f) {
            r.vy = 10f; r.onGround = false; r.cool = 0.5f
        }
        r.x += r.vx * dt; r.y += r.vy * dt; r.z += r.vz * dt

        if (r.y <= 0f && r.vy <= 0f && r.y > -0.6f && groundAt(r.z)) {
            r.y = 0f; r.vy = 0f; r.onGround = true
        } else r.onGround = false

        r.x = r.x.coerceIn(-HALF + 0.4f, HALF - 0.4f)
        if (r.z > 8f) r.z = 8f

        if (r.y < -14f) {
            r.x = (rnd.nextFloat() - 0.5f) * 6f; r.z = r.cpZ; r.y = 2.5f
            r.vx = 0f; r.vy = 0f; r.vz = 0f; r.stun = 0f
        }
        for (c in checkpoints) if (r.z < c && r.cpZ > c) r.cpZ = c + 2f

        // giradores
        for (s in spinners) {
            val a = t * s.speed
            val dx = cos(a); val dz = sin(a)
            val px = r.x - s.x; val pz = r.z - s.z
            val pr = (px * dx + pz * dz).coerceIn(-s.len, s.len)
            val ox = px - dx * pr; val oz = pz - dz * pr
            val d = sqrt(ox * ox + oz * oz)
            if (d < 0.75f && r.y < 0.8f) {
                var nx = ox; var nz = oz
                if (d < 0.001f) { nx = -dz; nz = dx } else { nx /= d; nz /= d }
                r.vx = nx * 11f; r.vz = nz * 11f; r.vy = 6f; r.onGround = false; r.stun = 0.9f
                r.x += nx * (0.75f - d); r.z += nz * (0.75f - d)
            }
        }
        // paredes deslizantes
        for (s in sliders) {
            val sx = sin(t * s.speed + s.ph) * s.range
            val svx = cos(t * s.speed + s.ph) * s.range * s.speed
            if (r.y < 1.5f) {
                val cx = r.x.coerceIn(sx - s.w / 2, sx + s.w / 2)
                val cz = r.z.coerceIn(s.z - 0.5f, s.z + 0.5f)
                val ox = r.x - cx; val oz = r.z - cz
                val d = sqrt(ox * ox + oz * oz)
                if (d < 0.45f) {
                    if (d < 0.001f) {
                        val nz = if (r.z > s.z) 1f else -1f
                        r.z = s.z + nz * 0.95f; r.vz = nz * 6f
                    } else {
                        val nx = ox / d; val nz = oz / d
                        r.x += nx * (0.45f - d); r.z += nz * (0.45f - d)
                        if (abs(nx) > 0.5f) r.vx = svx + nx * 4f else r.vz = nz * 6f
                    }
                    r.stun = max(r.stun, 0.5f)
                }
            }
        }
        // chegada
        if (!r.finished && r.z < -FIN) { r.finished = true; r.rank = ++finishCount }
        if (r.finished) { r.vx *= 0.9f; r.vz *= 0.9f }

        // virar o corpo e animar
        val sp = hypot(r.vx, r.vz)
        var target = r.yaw
        if (r.finished) target = 0f
        else if (sp > 0.6f && r.stun <= 0f) target = atan2(r.vx, r.vz)
        var dy = target - r.yaw
        while (dy > PI) dy -= (2 * PI).toFloat()
        while (dy < -PI) dy += (2 * PI).toFloat()
        r.yaw += dy * min(1f, dt * 12f)
        r.phase += sp * dt * 1.4f
    }
}
